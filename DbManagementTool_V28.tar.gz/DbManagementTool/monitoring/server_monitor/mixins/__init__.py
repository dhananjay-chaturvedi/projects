"""Mixins composing ServerMonitorUI."""
