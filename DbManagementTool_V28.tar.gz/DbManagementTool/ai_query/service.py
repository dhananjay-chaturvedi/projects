"""
AI Query service layer — natural language to SQL and multi-session API.

Uses a :class:`CoreDBService` for DB connections. Shipped with ``ai_query/`` only.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Optional

if TYPE_CHECKING:
    from common.headless.db_service import CoreDBService

try:
    from ai_query.agent import AIQueryAgent
    _AI_AVAILABLE = True
except ImportError:
    _AI_AVAILABLE = False
    AIQueryAgent = None


def make_service(core: Optional["CoreDBService"] = None):
    """Core + AI composite for module-only CLI/API."""
    from common.headless.composite import composite_service
    from common.headless.db_service import CoreDBService

    core = core or CoreDBService()
    return composite_service(core, AIService(core))


_AI_STATE_FILENAME = "ai_state.json"


def _ai_state_path():
    """Path to the persistent AI service state (CLI/API toggles).

    The file is human-readable JSON. We use it for settings that must survive
    a fresh CLI invocation — primarily ``mask_pii`` and ``active_backend``.
    Storage lives in :func:`common.paths.session_dir` (default
    ``<DBASSISTANT_HOME>/session/ai_state.json``).
    """
    from common import paths as _paths

    return _paths.ai_state_path()


def _read_ai_state() -> dict:
    import json
    path = _ai_state_path()
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _write_ai_state(state: dict) -> None:
    import json
    path = _ai_state_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(state, indent=2), encoding="utf-8")


class AIService:
    """Headless AI query API backed by a core connection service."""

    def __init__(self, core: Any):
        self._core = core
        self._ai = AIQueryAgent() if _AI_AVAILABLE else None
        # Re-apply any persisted settings (e.g. PII toggle, last backend).
        # Backend restore goes through verify=True so the underlying backend
        # object actually becomes "available" — without that, _call_ai
        # short-circuits with "No AI backend available."
        if self._ai is not None:
            persisted = _read_ai_state()
            if "mask_pii" in persisted and hasattr(self._ai, "set_mask_pii"):
                try:
                    self._ai.set_mask_pii(bool(persisted["mask_pii"]))
                except Exception:
                    pass
            backend = persisted.get("active_backend") or ""
            if backend:
                try:
                    if not self._ai.set_backend(backend, verify=True, quiet=True):
                        # Fall back to remembering the choice even when probe
                        # fails (network blip, missing CLI): the user gets a
                        # clearer error later instead of a silent default.
                        self._ai.set_backend(backend, verify=False, quiet=True)
                except Exception:
                    pass

    def _ai_or_error(self) -> tuple:
        if not _AI_AVAILABLE or self._ai is None:
            return None, {
                "error": "AI query agent not available (check ai_query/agent.py)"
            }
        return self._ai, None

    def _resolve_session_ref(self, ref: str):
        ai, err = self._ai_or_error()
        if err:
            return None, err
        sess = ai.sessions.resolve(ref)
        if not sess:
            return None, {"error": f"Session not found: {ref}"}
        return sess, None

    def _orchestrator(self):
        from ai_query.cross_tab_orchestrator import CrossTabOrchestrator

        return CrossTabOrchestrator(
            self._ai,
            self._ai.sessions,
            lambda name: self._core.get_manager(name),
        )

    def list_ai_backends(self) -> dict:
        if not _AI_AVAILABLE or self._ai is None:
            return {
                "available": False,
                "error": "AI query agent not available (check ai_query/agent.py)",
                "all": [],
                "ready": [],
                "active": "",
            }
        try:
            return {
                "available": True,
                "error": None,
                "all": self._ai.list_all_backends(),
                "ready": self._ai.list_available_backends(),
                "active": self._ai.get_active_backend_name(),
            }
        except Exception as exc:
            return {
                "available": False,
                "error": str(exc),
                "all": [],
                "ready": [],
                "active": "",
            }

    def ai_query(
        self,
        name: str,
        question: str,
        backend: str | None = None,
        *,
        sql_mode: str | None = None,
        sql_execution_rules: str | None = None,
    ) -> dict:
        if not _AI_AVAILABLE or self._ai is None:
            return {
                "sql": None,
                "explanation": None,
                "error": "AI query agent not available (check ai_query/agent.py)",
            }
        if backend and not self._ai.set_backend(backend):
            return {
                "sql": None,
                "explanation": None,
                "error": f"AI backend '{backend}' is not available.",
            }
        if not backend and not self._ai.is_available():
            self._ai.auto_select_backend()
        try:
            from ai_query.sql_execution_service import default_execution_rules_from_config
            from ai_query.sql_modes import normalize_sql_mode

            mgr = self._core.get_manager(name)
            sess = self._ai.sessions.create(connection_name=name, backend=backend or "")
            sess.sql_mode = normalize_sql_mode(sql_mode or sess.sql_mode or "summary")
            sess.sql_execution_rules = (
                sql_execution_rules
                if sql_execution_rules is not None
                else default_execution_rules_from_config()
            )
            sess.sql_modes_v2 = True
            result = self._ai.start_new_conversation(
                question, mgr, name, session_id=sess.session_id
            )
            self._ai.sessions.delete(sess.session_id)
            return {
                "sql": result.get("sql") or result.get("summary_sql"),
                "summary_sql": result.get("summary_sql") or result.get("sql"),
                "explanation": result.get("explanation"),
                "error": result.get("error"),
                "sql_mode": sess.sql_mode,
                "summary_mode_blocked": result.get("summary_mode_blocked"),
                "satisfied": result.get("satisfied"),
            }
        except Exception as exc:
            return {"sql": None, "explanation": None, "error": str(exc)}

    def ai_session_create(
        self,
        connection: str = "",
        backend: str | None = None,
        *,
        isolated: bool = False,
        share_context: bool = True,
        sql_mode: str | None = None,
        sql_execution_rules: str | None = None,
    ) -> dict:
        ai, err = self._ai_or_error()
        if err:
            return err
        try:
            from ai_query.sql_execution_service import default_execution_rules_from_config
            from ai_query.sql_modes import normalize_sql_mode

            sess = ai.sessions.create(
                connection_name=connection,
                backend=backend or "",
                isolated=isolated,
                share_context=share_context,
            )
            if sql_mode:
                sess.sql_mode = normalize_sql_mode(sql_mode)
            if sql_execution_rules is not None:
                sess.sql_execution_rules = sql_execution_rules
            elif not sess.sql_execution_rules:
                sess.sql_execution_rules = default_execution_rules_from_config()
            sess.sql_modes_v2 = True
            if backend:
                ai.set_backend(backend, verify=False)
                sess.backend = backend
            return {"session": sess.to_dict(), "error": None}
        except Exception as exc:
            return {"session": None, "error": str(exc)}

    def ai_session_list(self) -> dict:
        ai, err = self._ai_or_error()
        if err:
            return {**err, "sessions": []}
        return {"sessions": ai.sessions.list_sessions(), "error": None}

    def ai_session_get(self, ref: str) -> dict:
        sess, err = self._resolve_session_ref(ref)
        if err:
            return {**err, "session": None}
        return {"session": sess.summary(), "error": None}

    def ai_session_delete(self, ref: str) -> dict:
        ai, err = self._ai_or_error()
        if err:
            return err
        sess, err = self._resolve_session_ref(ref)
        if err:
            return err
        ok = ai.sessions.delete(sess.session_id)
        return {"deleted": ok, "error": None if ok else "Session not found"}

    def ai_session_update(self, ref: str, **fields) -> dict:
        sess, err = self._resolve_session_ref(ref)
        if err:
            return err
        from ai_query.sql_modes import normalize_sql_mode

        if "connection" in fields and fields["connection"] is not None:
            sess.connection_name = fields["connection"]
        if "backend" in fields and fields["backend"] is not None:
            sess.backend = fields["backend"]
            self._ai.set_backend(fields["backend"], verify=False)
        if "share_context" in fields and fields["share_context"] is not None:
            sess.share_context = bool(fields["share_context"])
        if "isolated" in fields and fields["isolated"] is not None:
            sess.isolated = bool(fields["isolated"])
        if "sql_mode" in fields and fields["sql_mode"] is not None:
            sess.sql_mode = normalize_sql_mode(fields["sql_mode"])
            sess.sql_modes_v2 = True
        if "sql_execution_rules" in fields and fields["sql_execution_rules"] is not None:
            sess.sql_execution_rules = fields["sql_execution_rules"]
        return {"session": sess.to_dict(), "error": None}

    def ai_session_ask(self, ref: str, question: str, *, mode: str = "ask") -> dict:
        ai, err = self._ai_or_error()
        if err:
            return {**err, "sql": None, "explanation": None}
        sess, err = self._resolve_session_ref(ref)
        if err:
            return {**err, "sql": None, "explanation": None}
        conn = sess.connection_name
        if not conn:
            return {
                "sql": None,
                "explanation": None,
                "error": "Session has no connection",
            }
        if sess.backend and not ai.is_available():
            ai.set_backend(sess.backend, verify=False)
        elif not ai.is_available():
            ai.auto_select_backend()
        try:
            mgr = self._core.get_manager(conn)
            out = self._orchestrator().parse_and_execute(
                sess.session_id,
                question,
                mgr,
                conn,
                mode="followup" if mode == "followup" else "ask",
            )
            if out.get("skip_local_ai"):
                result = out.get("result") or {}
                return {
                    "sql": result.get("sql"),
                    "explanation": result.get("explanation"),
                    "error": result.get("error"),
                    "cross_tab": out,
                }
            result = out.get("result") or {}
            return {
                "sql": result.get("sql") or result.get("summary_sql"),
                "summary_sql": result.get("summary_sql") or result.get("sql"),
                "explanation": result.get("explanation"),
                "error": result.get("error"),
                "sql_mode": sess.sql_mode,
                "summary_mode_blocked": result.get("summary_mode_blocked"),
                "satisfied": result.get("satisfied"),
                "cross_tab": {
                    "messages": out.get("cross_tab_messages", []),
                    "peer_bundles": len(out.get("peer_bundles") or []),
                },
            }
        except Exception as exc:
            return {"sql": None, "explanation": None, "error": str(exc)}

    def ai_session_execute_sql(self, ref: str, sql: str) -> dict:
        ai, err = self._ai_or_error()
        if err:
            return {**err, "result": None}
        sess, err = self._resolve_session_ref(ref)
        if err:
            return {**err, "result": None}
        conn = sess.connection_name
        if not conn:
            return {"error": "Session has no connection", "result": None}
        try:
            from ai_query.sql_execution_service import execute_sql_with_rules

            mgr = self._core.get_manager(conn)
            out = execute_sql_with_rules(
                sql,
                mgr,
                sql_mode=sess.sql_mode,
                rules_text=sess.sql_execution_rules,
                agent=ai,
                connection_name=conn,
            )
            if out.get("blocked"):
                return {
                    "error": out.get("error"),
                    "blocked": True,
                    "explain_output": out.get("explain_output"),
                    "result": None,
                }
            if out.get("error"):
                return {
                    "error": out.get("error"),
                    "explain_output": out.get("explain_output"),
                    "result": None,
                }
            return {
                "error": None,
                "explain_output": out.get("explain_output"),
                "explain_note": out.get("explain_note"),
                "result": out.get("result"),
            }
        except Exception as exc:
            return {"error": str(exc), "result": None}

    def ai_session_follow_up(self, ref: str, message: str) -> dict:
        return self.ai_session_ask(ref, message, mode="followup")

    def ai_session_cross_tab(self, ref: str, instruction: str) -> dict:
        ai, err = self._ai_or_error()
        if err:
            return err
        sess, err = self._resolve_session_ref(ref)
        if err:
            return err
        orch = self._orchestrator()
        route = orch.parse_route_target(instruction)
        if route:
            tab_n, msg = route
            return orch.route_to_tab(sess.session_id, tab_n, msg or instruction)
        tabs = orch.parse_tab_references(instruction)
        if len(tabs) > 1:
            return orch.coordinate_team(sess.session_id, instruction)
        conn = sess.connection_name
        if not conn:
            return {"error": "Session has no connection"}
        mgr = self._core.get_manager(conn)
        return orch.parse_and_execute(sess.session_id, instruction, mgr, conn)

    def ai_session_save(self, path: str | None = None) -> dict:
        from pathlib import Path as P

        from ai_query.session_manager import save_sessions_to_disk

        ai, err = self._ai_or_error()
        if err:
            return err
        try:
            p = save_sessions_to_disk(ai.sessions, P(path) if path else None)
            return {"path": str(p), "error": None}
        except Exception as exc:
            return {"path": None, "error": str(exc)}

    # ------------------------------------------------------------------
    # Parity additions (Phase 6) — explain / optimize / review SQL,
    # backend configure, schema-cache info/clear/show, PII toggle.
    # ------------------------------------------------------------------

    def _resolve_db_type(self, connection: str | None) -> str:
        """Best-effort resolution of a connection's db_type. Returns ``"SQL"``
        when the connection name is empty or cannot be resolved (no DB call).
        """
        if not connection:
            return "SQL"
        try:
            profile = self._core.get_connection_profile(connection)
            if profile:
                return profile.get("db_type") or "SQL"
        except Exception:
            pass
        return "SQL"

    @staticmethod
    def _is_agent_error_string(text: object) -> bool:
        """Detect known error-marker strings returned by ``AIQueryAgent``.

        ``explain_query`` / ``suggest_optimizations`` return raw strings; the
        UI inspects them by content. We mirror that detection here so the
        service surface always uses the ``{"error": ..., "...": None}``
        convention even when the underlying method doesn't.
        """
        if not isinstance(text, str):
            return False
        lower = text.lower().strip()
        if not lower:
            return True
        markers = (
            "claude cli not available",
            "ai cli not available",
            "ai backend not available",
            "could not generate",
            "error explaining",
            "error suggesting",
            "error:",
        )
        return any(lower.startswith(m) or m in lower[:120] for m in markers)

    def explain_sql(self, sql: str, connection: str = "", db_type: str = "") -> dict:
        """Explain a SQL statement (mirrors UI's "Explain query" button)."""
        ai, err = self._ai_or_error()
        if err:
            return {**err, "explanation": None}
        if not (sql or "").strip():
            return {"error": "Empty SQL.", "explanation": None}
        engine = db_type or self._resolve_db_type(connection)
        try:
            text = ai.explain_query(sql, engine)
            if self._is_agent_error_string(text):
                return {"error": str(text).strip() or "AI returned no response.",
                        "explanation": None, "db_type": engine}
            return {"error": None, "explanation": text, "db_type": engine}
        except Exception as exc:
            return {"error": str(exc), "explanation": None, "db_type": engine}

    def optimize_sql(self, sql: str, connection: str = "", db_type: str = "") -> dict:
        """Suggest optimizations for a SQL statement (UI's "Optimize")."""
        ai, err = self._ai_or_error()
        if err:
            return {**err, "suggestions": None}
        if not (sql or "").strip():
            return {"error": "Empty SQL.", "suggestions": None}
        engine = db_type or self._resolve_db_type(connection)
        try:
            text = ai.suggest_optimizations(sql, engine)
            if self._is_agent_error_string(text):
                return {"error": str(text).strip() or "AI returned no response.",
                        "suggestions": None, "db_type": engine}
            return {"error": None, "suggestions": text, "db_type": engine}
        except Exception as exc:
            return {"error": str(exc), "suggestions": None, "db_type": engine}

    def review_sql(
        self,
        sql: str,
        rules: str = "",
        connection: str = "",
        db_type: str = "",
        *,
        timeout: int = 60,
    ) -> dict:
        """Run the UI's "Run Review" prompt against the active AI backend.

        ``rules`` is the same free-form review criteria text the UI's "Write
        Review Rules" dialog persists. When empty, we use a sensible default.
        """
        ai, err = self._ai_or_error()
        if err:
            return {**err, "review": None}
        if not (sql or "").strip():
            return {"error": "Empty SQL.", "review": None}
        engine = db_type or self._resolve_db_type(connection)
        criteria = (rules or "").strip() or (
            "Use standard SQL best practices and performance optimization "
            "guidelines (indexes, WHERE clauses on UPDATE/DELETE, LIMIT on "
            "large result sets, N+1 patterns, SQL injection)."
        )
        prompt = (
            f"You are an expert SQL reviewer. Review the following {engine} "
            "SQL query based on these criteria:\n\n"
            f"REVIEW CRITERIA:\n{criteria}\n\n"
            f"SQL QUERY TO REVIEW:\n{sql}\n\n"
            "Please provide a comprehensive review with the following sections:\n"
            "1. STRENGTHS: What's done well in this query\n"
            "2. ISSUES: Problems, vulnerabilities, or bad practices found\n"
            "3. RECOMMENDATIONS: Specific improvements with examples\n"
            "4. PRIORITY: Rank issues by severity (Critical/High/Medium/Low)\n"
            "5. OPTIMIZED VERSION: Provide an improved version if significant "
            "changes are needed\n"
        )
        try:
            res = ai._call_ai(prompt, timeout=timeout)
            text = (res or {}).get("response") or ""
            if not text:
                return {
                    "error": (res or {}).get("error") or "AI returned no response.",
                    "review": None, "db_type": engine,
                }
            return {"error": None, "review": text, "db_type": engine}
        except Exception as exc:
            return {"error": str(exc), "review": None, "db_type": engine}

    def configure_ai_backend(self, name: str, verify: bool = True) -> dict:
        """Set the active AI backend (UI's "Backend" dropdown).

        Persists to ``<DBASSISTANT_HOME>/session/ai_state.json`` so the choice survives CLI
        invocations and matches the long-running API server state.
        """
        ai, err = self._ai_or_error()
        if err:
            return err
        try:
            ok = ai.set_backend(name, verify=bool(verify))
            active = ai.get_active_backend_name() if ok else ""
            if ok:
                state = _read_ai_state()
                state["active_backend"] = active or name
                _write_ai_state(state)
            return {
                "ok": bool(ok),
                "active": active,
                "message": (
                    "Backend set."
                    if ok
                    else f"AI backend '{name}' is not available."
                ),
            }
        except Exception as exc:
            return {"ok": False, "active": "", "message": str(exc)}

    def get_ai_cache_info(self) -> dict:
        """Schema-cache statistics for every connection currently cached."""
        ai, err = self._ai_or_error()
        if err:
            return {**err, "entries": []}
        try:
            entries = ai.get_cache_info() or []
            for e in entries:
                ts = e.get("timestamp")
                if ts is not None and not isinstance(ts, str):
                    e["timestamp"] = ts.strftime("%Y-%m-%d %H:%M:%S")
            return {"error": None, "entries": entries, "count": len(entries)}
        except Exception as exc:
            return {"error": str(exc), "entries": [], "count": 0}

    def clear_ai_cache(self, connection: str | None = None) -> dict:
        """Clear schema cache for *connection* (or all when omitted)."""
        ai, err = self._ai_or_error()
        if err:
            return err
        try:
            ai.invalidate_cache(connection or None)
            return {
                "ok": True,
                "message": (
                    f"Cache cleared for '{connection}'." if connection
                    else "All AI caches cleared."
                ),
            }
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def show_ai_cache(self, connection: str = "") -> dict:
        """Return cached schema info — either for one connection or last sent."""
        ai, err = self._ai_or_error()
        if err:
            return {**err, "schema": None}
        try:
            if connection:
                schema = ai.schema_cache.get(connection)
                if schema is None:
                    return {
                        "error": f"No cached schema for '{connection}'.",
                        "schema": None,
                        "connection": connection,
                    }
                return {"error": None, "schema": schema, "connection": connection}
            text = ai.get_last_schema_sent()
            return {"error": None, "schema_last_sent": text, "connection": ""}
        except Exception as exc:
            return {"error": str(exc), "schema": None}

    def get_pii_masking(self) -> dict:
        """Current state of PII masking on the AI agent."""
        ai, err = self._ai_or_error()
        if err:
            return {**err, "enabled": False}
        try:
            return {
                "error": None,
                "enabled": bool(getattr(ai, "mask_pii_enabled", True)),
            }
        except Exception as exc:
            return {"error": str(exc), "enabled": False}

    def set_pii_masking(self, enabled: bool) -> dict:
        """Toggle PII masking on the AI agent (UI's "Mask PII data" menu).

        Persists to ``<DBASSISTANT_HOME>/session/ai_state.json`` so the toggle survives CLI
        invocations (each CLI call spawns a fresh process which would
        otherwise re-read the config default).
        """
        ai, err = self._ai_or_error()
        if err:
            return err
        try:
            ai.set_mask_pii(bool(enabled))
            state = _read_ai_state()
            state["mask_pii"] = bool(enabled)
            _write_ai_state(state)
            return {
                "ok": True,
                "enabled": bool(getattr(ai, "mask_pii_enabled", enabled)),
                "message": (
                    "PII masking enabled." if enabled else "PII masking disabled."
                ),
            }
        except Exception as exc:
            return {"ok": False, "enabled": False, "message": str(exc)}

    def ai_session_load(self, path: str | None = None) -> dict:
        from pathlib import Path as P

        from ai_query.session_manager import load_sessions_from_disk

        ai, err = self._ai_or_error()
        if err:
            return err
        try:
            p = load_sessions_from_disk(ai.sessions, P(path) if path else None)
            return {
                "path": str(p),
                "sessions": ai.sessions.list_sessions(),
                "error": None,
            }
        except Exception as exc:
            return {"path": None, "sessions": [], "error": str(exc)}
