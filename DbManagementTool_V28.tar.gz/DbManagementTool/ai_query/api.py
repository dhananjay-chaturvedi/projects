"""
REST API surface for the AI Query Assistant module.
"""

from __future__ import annotations

from pydantic import BaseModel, Field


class AIQueryRequest(BaseModel):
    connection: str = Field(..., examples=["my_mysql"])
    question: str = Field(..., examples=["show tables with more than 1000 rows"])
    backend: str = Field("", examples=[""], description="Optional AI backend; blank = auto")
    sql_mode: str = Field(
        "",
        description="strict_summary | summary | open (default: summary)",
    )
    sql_execution_rules: str = Field(
        "",
        description="Optional execution rules text (summary/open modes)",
    )


class SessionCreate(BaseModel):
    connection: str = ""
    backend: str = ""
    isolated: bool = False
    share_context: bool = True
    sql_mode: str = Field("", description="strict_summary | summary | open")
    sql_execution_rules: str = ""


class SessionMessage(BaseModel):
    message: str
    mode: str = Field("ask", description="ask or followup")


class SessionCrossTab(BaseModel):
    instruction: str


class SessionExecuteSQL(BaseModel):
    sql: str


class SessionPatch(BaseModel):
    connection: str | None = None
    backend: str | None = None
    share_context: bool | None = None
    isolated: bool | None = None
    sql_mode: str | None = None
    sql_execution_rules: str | None = None


class SessionSaveLoad(BaseModel):
    path: str = ""


class AiConfigSet(BaseModel):
    section: str
    key: str
    value: str


class SQLAnalyseRequest(BaseModel):
    sql: str = Field(..., min_length=1, examples=["SELECT * FROM users"])
    connection: str = Field("", examples=["my_mysql"])
    db_type: str = Field("", examples=["MySQL", "PostgreSQL"])


class SQLReviewRequest(SQLAnalyseRequest):
    rules: str = Field("", description="Optional review rules text")
    timeout: int = Field(60, ge=5, le=600)


class BackendConfigureRequest(BaseModel):
    backend: str = Field(..., examples=["claude"])
    verify: bool = Field(True, description="Skip availability check when false")


class PIIToggleRequest(BaseModel):
    enabled: bool = Field(..., examples=[True])


def build_router(svc=None):
    from fastapi import APIRouter, HTTPException

    if svc is None:
        from ai_query.service import make_service

        svc = make_service()

    router = APIRouter(tags=["AI"])

    def _error(detail: str, status: int = 400):
        raise HTTPException(status_code=status, detail=detail)

    @router.post("/api/ai/query")
    def ai_query(req: AIQueryRequest):
        """Convert a natural-language question to SQL using the AI agent."""
        r = svc.ai_query(
            req.connection,
            req.question,
            backend=req.backend or None,
            sql_mode=req.sql_mode or None,
            sql_execution_rules=req.sql_execution_rules or None,
        )
        if r.get("error") and not r.get("sql"):
            _error(r["error"])
        return r

    @router.get("/api/ai/backends")
    def ai_backends():
        """List configured AI backends and which are verified available."""
        info = svc.list_ai_backends()
        if not info.get("available"):
            _error(info.get("error") or "AI not available.")
        return info

    @router.post("/api/ai/sessions")
    def ai_session_create(req: SessionCreate):
        r = svc.ai_session_create(
            req.connection,
            req.backend or None,
            isolated=req.isolated,
            share_context=req.share_context,
            sql_mode=req.sql_mode or None,
            sql_execution_rules=req.sql_execution_rules or None,
        )
        if r.get("error"):
            _error(r["error"])
        return r

    @router.get("/api/ai/sessions")
    def ai_session_list():
        r = svc.ai_session_list()
        if r.get("error"):
            _error(r["error"])
        return r

    @router.get("/api/ai/sessions/{session_id}")
    def ai_session_get(session_id: str):
        r = svc.ai_session_get(session_id)
        if r.get("error"):
            _error(r["error"])
        return r

    @router.patch("/api/ai/sessions/{session_id}")
    def ai_session_patch(session_id: str, req: SessionPatch):
        r = svc.ai_session_update(session_id, **req.model_dump(exclude_unset=True))
        if r.get("error"):
            _error(r["error"])
        return r

    @router.delete("/api/ai/sessions/{session_id}")
    def ai_session_delete(session_id: str):
        r = svc.ai_session_delete(session_id)
        if r.get("error"):
            _error(r["error"])
        return r

    @router.post("/api/ai/sessions/{session_id}/messages")
    def ai_session_message(session_id: str, req: SessionMessage):
        mode = "followup" if req.mode == "followup" else "ask"
        r = svc.ai_session_ask(session_id, req.message, mode=mode)
        if r.get("error") and not r.get("sql"):
            _error(r["error"])
        return r

    @router.post("/api/ai/sessions/{session_id}/cross-tab")
    def ai_session_cross(session_id: str, req: SessionCrossTab):
        r = svc.ai_session_cross_tab(session_id, req.instruction)
        if r.get("error") and not r.get("routed"):
            _error(r["error"])
        return r

    @router.post("/api/ai/sessions/{session_id}/execute-sql")
    def ai_session_execute_sql(session_id: str, req: SessionExecuteSQL):
        """Execute SQL with session sql_mode and execution rules."""
        r = svc.ai_session_execute_sql(session_id, req.sql)
        if r.get("error") and not r.get("result"):
            _error(r["error"])
        return r

    @router.post("/api/ai/sessions/save")
    def ai_sessions_save(req: SessionSaveLoad):
        r = svc.ai_session_save(req.path or None)
        if r.get("error"):
            _error(r["error"])
        return r

    @router.post("/api/ai/sessions/load")
    def ai_sessions_load(req: SessionSaveLoad):
        r = svc.ai_session_load(req.path or None)
        if r.get("error"):
            _error(r["error"])
        return r

    # -- Phase 6 parity ----------------------------------------------------

    @router.post("/api/ai/explain")
    def ai_explain(req: SQLAnalyseRequest):
        if not hasattr(svc, "explain_sql"):
            _error("explain_sql not supported.", 501)
        r = svc.explain_sql(req.sql, connection=req.connection, db_type=req.db_type)
        if r.get("error"):
            _error(r["error"])
        return r

    @router.post("/api/ai/optimize")
    def ai_optimize(req: SQLAnalyseRequest):
        if not hasattr(svc, "optimize_sql"):
            _error("optimize_sql not supported.", 501)
        r = svc.optimize_sql(req.sql, connection=req.connection, db_type=req.db_type)
        if r.get("error"):
            _error(r["error"])
        return r

    @router.post("/api/ai/review")
    def ai_review(req: SQLReviewRequest):
        if not hasattr(svc, "review_sql"):
            _error("review_sql not supported.", 501)
        r = svc.review_sql(
            req.sql, rules=req.rules, connection=req.connection,
            db_type=req.db_type, timeout=req.timeout,
        )
        if r.get("error"):
            _error(r["error"])
        return r

    @router.put("/api/ai/backend")
    def ai_backend_configure(req: BackendConfigureRequest):
        if not hasattr(svc, "configure_ai_backend"):
            _error("configure_ai_backend not supported.", 501)
        r = svc.configure_ai_backend(req.backend, verify=req.verify)
        if not r["ok"]:
            _error(r["message"])
        return r

    @router.get("/api/ai/cache")
    def ai_cache_info():
        if not hasattr(svc, "get_ai_cache_info"):
            _error("get_ai_cache_info not supported.", 501)
        r = svc.get_ai_cache_info()
        if r.get("error"):
            _error(r["error"])
        return r

    @router.delete("/api/ai/cache")
    def ai_cache_clear(connection: str = ""):
        if not hasattr(svc, "clear_ai_cache"):
            _error("clear_ai_cache not supported.", 501)
        r = svc.clear_ai_cache(connection or None)
        if not r["ok"]:
            _error(r["message"])
        return r

    @router.get("/api/ai/cache/show")
    def ai_cache_show(connection: str = ""):
        if not hasattr(svc, "show_ai_cache"):
            _error("show_ai_cache not supported.", 501)
        r = svc.show_ai_cache(connection or "")
        if r.get("error"):
            _error(r["error"], 404 if "No cached" in r["error"] else 400)
        return r

    @router.get("/api/ai/pii")
    def ai_pii_status():
        if not hasattr(svc, "get_pii_masking"):
            _error("get_pii_masking not supported.", 501)
        r = svc.get_pii_masking()
        if r.get("error"):
            _error(r["error"])
        return r

    @router.put("/api/ai/pii")
    def ai_pii_set(req: PIIToggleRequest):
        if not hasattr(svc, "set_pii_masking"):
            _error("set_pii_masking not supported.", 501)
        r = svc.set_pii_masking(req.enabled)
        if not r["ok"]:
            _error(r["message"])
        return r

    @router.get("/api/ai/config", tags=["Config"])
    def ai_config_get():
        from ai_query import module_config as mc
        return {
            "ok": True,
            "config": {s: {k: mc.get(s, k) for k in keys} for s, keys in mc.DEFAULTS.items()},
            "path": str(mc.config_path() or mc.live_path()),
        }

    @router.post("/api/ai/config", tags=["Config"])
    def ai_config_set(req: AiConfigSet):
        from ai_query import module_config as mc
        if req.section not in mc.DEFAULTS or req.key not in mc.DEFAULTS[req.section]:
            _error(f"Unknown setting {req.section}.{req.key}")
        mc.set_value(req.section, req.key, req.value)
        return {"ok": True, "message": f"{req.section}.{req.key} saved."}

    @router.post("/api/ai/config/restore", tags=["Config"])
    def ai_config_restore():
        from ai_query import module_config as mc
        mc.restore_defaults()
        return {"ok": True, "message": "config.ini restored."}

    return router
