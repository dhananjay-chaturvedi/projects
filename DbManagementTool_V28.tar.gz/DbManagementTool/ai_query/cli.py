"""
CLI surface for the AI Query Assistant module.

Exposes the ``ai`` command (natural-language → SQL, plus backend listing).
Wired into the master CLI through the manifest; runnable standalone via
``python -m ai_query``.
"""

from __future__ import annotations

from common.core import cliutil

_SQL_MODE_CHOICES = ("strict_summary", "summary", "open")


def _add_sql_mode_args(parser):
    parser.add_argument(
        "--sql-mode",
        choices=_SQL_MODE_CHOICES,
        default="",
        help="SQL mode: strict_summary | summary | open",
    )
    parser.add_argument(
        "--execution-rules",
        default="",
        metavar="TEXT",
        help="SQL execution rules (summary/open); or use --execution-rules-file",
    )
    parser.add_argument(
        "--execution-rules-file",
        default="",
        metavar="PATH",
        help="File containing SQL execution rules (one per line)",
    )


def _resolve_execution_rules(args) -> str | None:
    path = getattr(args, "execution_rules_file", "") or ""
    text = getattr(args, "execution_rules", "") or ""
    if path:
        from pathlib import Path
        text = Path(path).read_text(encoding="utf-8").strip()
    return text if text else None


def _resolve_sql_mode(args) -> str | None:
    mode = getattr(args, "sql_mode", "") or ""
    return mode or None


def register_cli(subparsers) -> None:
    ai_p = subparsers.add_parser("ai", help="AI natural-language → SQL")
    ai_sub = ai_p.add_subparsers(dest="ai_subcommand", required=False)

    sp = ai_sub.add_parser("session", help="Manage AI query sessions")
    sp_sub = sp.add_subparsers(dest="session_cmd", required=True)

    def _add_session_ref(parser):
        parser.add_argument("--session", required=True, metavar="ID|tabN")

    p_list = sp_sub.add_parser("list", help="List sessions")
    p_list.add_argument("--format", choices=["table", "json", "csv"], default="table")

    p_new = sp_sub.add_parser("new", help="Create session")
    p_new.add_argument("--conn", default="", metavar="NAME")
    p_new.add_argument("--backend", default="", metavar="NAME")
    p_new.add_argument("--isolated", action="store_true")
    p_new.add_argument("--format", choices=["table", "json", "csv"], default="table")
    _add_sql_mode_args(p_new)

    p_ask = sp_sub.add_parser("ask", help="Ask in a session")
    _add_session_ref(p_ask)
    p_ask.add_argument("question", nargs="+")

    p_fu = sp_sub.add_parser("follow-up", help="Follow-up in a session")
    _add_session_ref(p_fu)
    p_fu.add_argument("message", nargs="+")

    p_exec = sp_sub.add_parser("execute-sql", help="Execute SQL with session execution rules")
    _add_session_ref(p_exec)
    p_exec.add_argument("--sql", required=True, help="SQL to execute")
    p_exec.add_argument("--format", choices=["table", "json", "csv"], default="table")

    p_mode = sp_sub.add_parser("set-mode", help="Update session SQL mode / execution rules")
    _add_session_ref(p_mode)
    _add_sql_mode_args(p_mode)

    p_cross = sp_sub.add_parser("cross", help="Cross-tab instruction")
    _add_session_ref(p_cross)
    p_cross.add_argument("instruction", nargs="+")

    p_close = sp_sub.add_parser("close", help="Close session")
    _add_session_ref(p_close)

    p_save = sp_sub.add_parser("save", help="Save sessions to disk")
    p_save.add_argument("--file", default="", metavar="PATH")

    p_load = sp_sub.add_parser("load", help="Load sessions from disk")
    p_load.add_argument("--file", default="", metavar="PATH")

    # Phase 6 parity: explain / optimize / review / configure / cache / pii
    p_exp = ai_sub.add_parser("explain", help="Explain a SQL statement (UI's 'Explain query')")
    p_exp.add_argument("--sql", default="", help="SQL string (or use --sql-file)")
    p_exp.add_argument("--sql-file", default="", dest="sql_file",
                       help="Path to a file containing the SQL")
    p_exp.add_argument("--conn", default="",
                       help="Saved connection to infer db_type from")
    p_exp.add_argument("--db-type", default="", dest="db_type",
                       help="Override db_type (MySQL, PostgreSQL, ...)")

    p_opt = ai_sub.add_parser("optimize", help="Suggest optimizations (UI's 'Optimize')")
    p_opt.add_argument("--sql", default="")
    p_opt.add_argument("--sql-file", default="", dest="sql_file")
    p_opt.add_argument("--conn", default="")
    p_opt.add_argument("--db-type", default="", dest="db_type")

    p_rev = ai_sub.add_parser("review", help="Run AI SQL review (UI's 'Run Review')")
    p_rev.add_argument("--sql", default="")
    p_rev.add_argument("--sql-file", default="", dest="sql_file")
    p_rev.add_argument("--rules", default="", help="Inline review-rules text")
    p_rev.add_argument("--rules-file", default="", dest="rules_file",
                       help="Path to a file containing review rules")
    p_rev.add_argument("--conn", default="")
    p_rev.add_argument("--db-type", default="", dest="db_type")
    p_rev.add_argument("--timeout", type=int, default=60)

    p_cfg = ai_sub.add_parser("configure", help="Set the active AI backend")
    p_cfg.add_argument("--backend", required=True, help="Backend name")
    p_cfg.add_argument("--no-verify", action="store_true", dest="no_verify",
                       help="Skip backend availability check")

    p_cache = ai_sub.add_parser("cache", help="Inspect / clear the AI schema cache")
    p_cache_sub = p_cache.add_subparsers(dest="cache_action", required=True)
    p_cache_info = p_cache_sub.add_parser("info", help="Show cache statistics")
    p_cache_info.add_argument("--format", choices=["table", "json", "csv"], default="table")
    p_cache_clear = p_cache_sub.add_parser("clear", help="Clear cache (all or one)")
    p_cache_clear.add_argument("--conn", default="",
                               help="Connection to clear; omit to clear all")
    p_cache_show = p_cache_sub.add_parser("show", help="Dump cached schema info")
    p_cache_show.add_argument("--conn", default="",
                              help="Connection name; omit for last-sent context")
    p_cache_show.add_argument("--format", choices=["table", "json"], default="json")

    p_pii = ai_sub.add_parser("pii", help="Inspect / toggle PII masking")
    p_pii_sub = p_pii.add_subparsers(dest="pii_action", required=True)
    p_pii_sub.add_parser("status", help="Show whether PII masking is enabled")
    p_pii_on = p_pii_sub.add_parser("on", help="Enable PII masking")
    p_pii_off = p_pii_sub.add_parser("off", help="Disable PII masking")
    _ = (p_pii_on, p_pii_off)

    mcfg_p = ai_sub.add_parser("config", help="View/edit ai_query/config.ini")
    mcfg_sub = mcfg_p.add_subparsers(dest="ai_config_action", required=True)
    mcfg_show = mcfg_sub.add_parser("show", help="Show module config")
    mcfg_show.add_argument("--format", choices=["table", "json"], default="table")
    mcfg_show.add_argument("--section", default="")
    mcfg_set = mcfg_sub.add_parser("set", help="Set one config value")
    mcfg_set.add_argument("section")
    mcfg_set.add_argument("key")
    mcfg_set.add_argument("value")
    mcfg_sub.add_parser("restore", help="Restore config.ini from .example")

    # Stateless one-shot (default when no subcommand)
    ai_p.add_argument("--conn", metavar="NAME",
                      help="Connection to use (required unless --list-backends / session)")
    ai_p.add_argument("--backend", default="", metavar="NAME",
                      help="AI backend to use (default: auto-select)")
    ai_p.add_argument("--list-backends", action="store_true", dest="list_backends",
                      help="List configured AI backends and exit")
    ai_p.add_argument("--format", choices=["table", "json", "csv"], default="table")
    _add_sql_mode_args(ai_p)
    ai_p.add_argument(
        "question",
        nargs="*",
        default=[],
        help="Natural language question (one-shot mode)",
    )


def _service():
    from ai_query.service import make_service

    return make_service()




def _dispatch_session(args) -> int:
    svc = _service()
    cmd = getattr(args, "session_cmd", None)
    if cmd == "list":
        r = svc.ai_session_list()
        if r.get("error"):
            cliutil.err(r["error"])
            return 1
        rows = [[s["tab_number"], s["session_id"][:8], s.get("connection_name", ""), s.get("backend", ""), s.get("status", "")]
                for s in r.get("sessions") or []]
        cliutil.print_table(rows, ["tab", "session", "connection", "backend", "status"], args.format)
        return 0
    if cmd == "new":
        r = svc.ai_session_create(
            args.conn,
            args.backend or None,
            isolated=args.isolated,
            sql_mode=_resolve_sql_mode(args),
            sql_execution_rules=_resolve_execution_rules(args),
        )
        if r.get("error"):
            cliutil.err(r["error"])
            return 1
        s = r["session"]
        cliutil.info(
            f"Created tab {s['tab_number']} session {s['session_id']} "
            f"mode={s.get('sql_mode', 'summary')}"
        )
        return 0
    if cmd == "ask":
        q = " ".join(args.question)
        r = svc.ai_session_ask(args.session, q, mode="ask")
        return _print_ai_result(r)
    if cmd == "follow-up":
        m = " ".join(args.message)
        r = svc.ai_session_follow_up(args.session, m)
        return _print_ai_result(r)
    if cmd == "set-mode":
        fields = {}
        mode = _resolve_sql_mode(args)
        rules = _resolve_execution_rules(args)
        if mode:
            fields["sql_mode"] = mode
        if rules is not None:
            fields["sql_execution_rules"] = rules
        if not fields:
            cliutil.err("Provide --sql-mode and/or --execution-rules")
            return 2
        r = svc.ai_session_update(args.session, **fields)
        if r.get("error"):
            cliutil.err(r["error"])
            return 1
        s = r["session"]
        cliutil.info(f"Updated session mode={s.get('sql_mode')} rules={'yes' if s.get('sql_execution_rules') else 'no'}")
        return 0
    if cmd == "execute-sql":
        r = svc.ai_session_execute_sql(args.session, args.sql)
        if r.get("error"):
            cliutil.err(r["error"])
            return 1
        if r.get("explain_output"):
            print(cliutil.bold("EXPLAIN:"))
            print(r["explain_output"])
        result = r.get("result") or {}
        if result.get("message"):
            print(result["message"])
        elif result.get("columns"):
            cliutil.print_table(
                result.get("rows") or [],
                result.get("columns") or [],
                args.format,
            )
        return 0
    if cmd == "cross":
        instr = " ".join(args.instruction)
        r = svc.ai_session_cross_tab(args.session, instr)
        if r.get("error") and not r.get("routed"):
            cliutil.err(r["error"])
            return 1
        cliutil.info(str(r))
        return 0
    if cmd == "close":
        r = svc.ai_session_delete(args.session)
        if r.get("error"):
            cliutil.err(r["error"])
            return 1
        cliutil.info("Session closed.")
        return 0
    if cmd == "save":
        r = svc.ai_session_save(args.file or None)
        if r.get("error"):
            cliutil.err(r["error"])
            return 1
        cliutil.info(f"Saved to {r['path']}")
        return 0
    if cmd == "load":
        r = svc.ai_session_load(args.file or None)
        if r.get("error"):
            cliutil.err(r["error"])
            return 1
        cliutil.info(f"Loaded from {r['path']} ({len(r.get('sessions') or [])} sessions)")
        return 0
    cliutil.err("Unknown session command")
    return 2


def _print_ai_result(r) -> int:
    if r.get("error"):
        cliutil.err(r["error"])
        return 1
    if r.get("sql"):
        print(cliutil.bold("Generated SQL:"))
        print(r["sql"])
    if r.get("explanation"):
        print()
        print(cliutil.bold("Explanation:"))
        print(r["explanation"])
    for msg in (r.get("cross_tab") or {}).get("messages") or []:
        print(cliutil.bold("Cross-tab:"), msg)
    return 0

def _load_sql_arg(args) -> tuple[str | None, int]:
    """Return (sql_text, error_code). error_code==0 means OK."""
    from pathlib import Path

    sql = getattr(args, "sql", "") or ""
    sql_file = getattr(args, "sql_file", "") or ""
    if sql_file:
        try:
            sql = Path(sql_file).read_text(encoding="utf-8")
        except OSError as exc:
            cliutil.err(str(exc))
            return None, 1
    if not (sql or "").strip():
        cliutil.err("Provide SQL via --sql or --sql-file.")
        return None, 2
    return sql, 0


def _load_rules_arg(args) -> str:
    from pathlib import Path

    rules = getattr(args, "rules", "") or ""
    rules_file = getattr(args, "rules_file", "") or ""
    if rules_file:
        try:
            rules = Path(rules_file).read_text(encoding="utf-8")
        except OSError as exc:
            cliutil.err(str(exc))
            return ""
    return rules


def _dispatch_explain(args) -> int:
    sql, code = _load_sql_arg(args)
    if sql is None:
        return code
    r = _service().explain_sql(sql, connection=args.conn or "",
                               db_type=args.db_type or "")
    if r.get("error"):
        cliutil.err(r["error"])
        return 1
    print(cliutil.bold(f"Explanation ({r.get('db_type', 'SQL')}):"))
    print(r.get("explanation") or "")
    return 0


def _dispatch_optimize(args) -> int:
    sql, code = _load_sql_arg(args)
    if sql is None:
        return code
    r = _service().optimize_sql(sql, connection=args.conn or "",
                                db_type=args.db_type or "")
    if r.get("error"):
        cliutil.err(r["error"])
        return 1
    print(cliutil.bold(f"Optimizations ({r.get('db_type', 'SQL')}):"))
    print(r.get("suggestions") or "")
    return 0


def _dispatch_review(args) -> int:
    sql, code = _load_sql_arg(args)
    if sql is None:
        return code
    rules = _load_rules_arg(args)
    r = _service().review_sql(
        sql, rules=rules, connection=args.conn or "",
        db_type=args.db_type or "", timeout=args.timeout or 60,
    )
    if r.get("error"):
        cliutil.err(r["error"])
        return 1
    print(cliutil.bold(f"SQL Review ({r.get('db_type', 'SQL')}):"))
    print(r.get("review") or "")
    return 0


def _dispatch_configure(args) -> int:
    r = _service().configure_ai_backend(args.backend, verify=not args.no_verify)
    (cliutil.ok if r["ok"] else cliutil.err)(r["message"])
    cliutil.info(f"Active backend: {r.get('active') or '(none)'}")
    return 0 if r["ok"] else 1


def _dispatch_cache(args) -> int:
    svc = _service()
    act = getattr(args, "cache_action", None)
    if act == "info":
        r = svc.get_ai_cache_info()
        if r.get("error"):
            cliutil.err(r["error"])
            return 1
        rows = [
            [e.get("connection", ""), e.get("db_type", ""),
             e.get("timestamp", ""), e.get("table_count", 0)]
            for e in r.get("entries") or []
        ]
        cliutil.print_table(
            rows, ["connection", "db_type", "cached_at", "tables"], args.format,
        )
        cliutil.info(f"{r.get('count', 0)} cache entries.")
        return 0
    if act == "clear":
        r = svc.clear_ai_cache(args.conn or None)
        (cliutil.ok if r["ok"] else cliutil.err)(r["message"])
        return 0 if r["ok"] else 1
    if act == "show":
        r = svc.show_ai_cache(args.conn or "")
        if r.get("error"):
            cliutil.err(r["error"])
            return 1
        import json
        if args.format == "json":
            print(json.dumps(
                {k: v for k, v in r.items() if k != "error"},
                indent=2, default=str,
            ))
        else:
            if r.get("schema") is not None:
                print(json.dumps(r["schema"], indent=2, default=str))
            else:
                print(r.get("schema_last_sent") or "")
        return 0
    cliutil.err("Unknown cache action.")
    return 2


def _dispatch_pii(args) -> int:
    svc = _service()
    act = getattr(args, "pii_action", None)
    if act == "status":
        r = svc.get_pii_masking()
        if r.get("error"):
            cliutil.err(r["error"])
            return 1
        cliutil.info(f"PII masking: {'on' if r['enabled'] else 'off'}")
        return 0
    if act == "on":
        r = svc.set_pii_masking(True)
        (cliutil.ok if r["ok"] else cliutil.err)(r["message"])
        return 0 if r["ok"] else 1
    if act == "off":
        r = svc.set_pii_masking(False)
        (cliutil.ok if r["ok"] else cliutil.err)(r["message"])
        return 0 if r["ok"] else 1
    cliutil.err("Unknown pii action.")
    return 2


def _dispatch_ai_config(args) -> int:
    import json
    from ai_query import module_config as mc

    act = args.ai_config_action
    if act == "show":
        sec_filter = (getattr(args, "section", "") or "").strip()
        if args.format == "json":
            out = {s: {k: mc.get(s, k) for k in keys} for s, keys in mc.DEFAULTS.items()}
            if sec_filter:
                out = {sec_filter: out.get(sec_filter, {})}
            print(json.dumps(out, indent=2))
            return 0
        for sec, keys in sorted(mc.DEFAULTS.items()):
            if sec_filter and sec != sec_filter:
                continue
            cliutil.info(f"[{sec}]")
            cliutil.print_table(
                [[k, mc.get(sec, k)] for k in sorted(keys)], ["key", "value"], "table"
            )
        return 0
    if act == "set":
        mc.set_value(args.section, args.key, args.value)
        cliutil.ok(f"{args.section}.{args.key} saved.")
        return 0
    if act == "restore":
        mc.restore_defaults()
        cliutil.ok("ai_query/config.ini restored from .example.")
        return 0
    return 2


def dispatch_cli(args) -> int:
    sub = getattr(args, "ai_subcommand", None)
    if sub == "session":
        return _dispatch_session(args)
    if sub == "explain":
        return _dispatch_explain(args)
    if sub == "optimize":
        return _dispatch_optimize(args)
    if sub == "review":
        return _dispatch_review(args)
    if sub == "configure":
        return _dispatch_configure(args)
    if sub == "cache":
        return _dispatch_cache(args)
    if sub == "pii":
        return _dispatch_pii(args)
    if sub == "config":
        return _dispatch_ai_config(args)
    if getattr(args, "list_backends", False):
        info = _service().list_ai_backends()
        if not info.get("available"):
            cliutil.err(info.get("error") or "AI not available.")
            return 1
        ready = set(info.get("ready") or [])
        active = info.get("active") or ""
        rows = []
        for b in (info.get("all") or []):
            status = "ready" if b in ready else "not verified"
            mark = " *" if b == active else ""
            rows.append([b + mark, status])
        cliutil.print_table(rows, ["backend", "status"], args.format)
        cliutil.info("* = active backend")
        return 0

    if not args.conn:
        cliutil.err("--conn is required to ask a question.")
        return 2
    if not args.question:
        cliutil.err("Provide a question, or use --list-backends.")
        return 2

    question = " ".join(args.question)
    cliutil.info(f"Asking AI: {question}")
    r = _service().ai_query(
        args.conn,
        question,
        backend=args.backend or None,
        sql_mode=_resolve_sql_mode(args),
        sql_execution_rules=_resolve_execution_rules(args),
    )
    if r.get("error"):
        cliutil.err(r["error"])
        return 1
    if r.get("sql"):
        print(cliutil.bold("Generated SQL:"))
        print(r["sql"])
    if r.get("explanation"):
        print()
        print(cliutil.bold("Explanation:"))
        print(r["explanation"])
    return 0
