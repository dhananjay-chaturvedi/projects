"""
ai_query/backends/__init__.py
==============================
AI backend abstraction layer.

Every backend exposes the same two methods:
    is_available() -> bool
    call(prompt, timeout) -> {"response": str | None, "error": str | None}

The registry auto-detects which CLIs are installed and returns only
the ones that actually work on this machine.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
from typing import Any, Optional

from common.config_loader import console_print
from ai_query import module_config as mc


# ── CLI resolution ──────────────────────────────────────────────────────────────
#
# GUI / launchd processes on macOS (and terminals opened before a PATH change)
# frequently run with a minimal PATH (e.g. /usr/bin:/bin) that does NOT include
# user install dirs like ~/.local/bin.  Relying on shutil.which() alone then makes
# perfectly-installed CLIs look "not installed".  resolve_cli() falls back to a set
# of well-known install locations and honours an explicit config override.

_COMMON_BIN_DIRS = [
    "~/.local/bin",
    "~/bin",
    "~/.claude/local",
    "/opt/homebrew/bin",
    "/usr/local/bin",
    "/usr/bin",
    "/opt/local/bin",
]


def resolve_cli(command: str, override: str = "") -> Optional[str]:
    """
    Locate *command* and return an absolute path, or None if not found.

    Resolution order:
      1. explicit override (a full path to the binary, or a directory holding it)
      2. shutil.which() against the current PATH
      3. a scan of common user/system install directories
    """
    def _ok(p: str) -> bool:
        return bool(p) and os.path.isfile(p) and os.access(p, os.X_OK)

    if override:
        cand = os.path.expanduser(override)
        if _ok(cand):
            return cand
        joined = os.path.join(cand, command)
        if _ok(joined):
            return joined

    found = shutil.which(command)
    if found:
        return found

    for d in _COMMON_BIN_DIRS:
        cand = os.path.join(os.path.expanduser(d), command)
        if _ok(cand):
            return cand
    return None


# ── Base class ────────────────────────────────────────────────────────────────

class AIBackend:
    """Abstract base for all AI CLI backends."""

    name: str = "base"          # short id used in dropdown / config
    display_name: str = "AI"    # human-readable label
    cli_command: str = ""       # executable to look for in PATH

    def __init__(self):
        self._cli_path: Optional[str] = None
        self._available: Optional[bool] = None  # None = not yet checked
        self._unavail_reason: str = ""           # populated when _detect fails

    # ── availability ─────────────────────────────────────────────────────────

    def is_available(self) -> bool:
        """Return cached availability. Does NOT probe if never checked."""
        return bool(self._available)

    def is_checked(self) -> bool:
        """True if availability has already been determined (cached)."""
        return self._available is not None

    def check_availability(self, force: bool = False) -> bool:
        """
        Run the actual availability probe (subprocess / network).
        Cached after first call unless force=True is passed.
        Call this explicitly — e.g. when the user selects a backend.
        """
        if self._available is not None and not force:
            return self._available
        self._unavail_reason = ""
        try:
            self._available = self._detect()
        except Exception as exc:                     # noqa: BLE001
            self._available = False
            if not self._unavail_reason:
                self._unavail_reason = f"detection error: {exc}"
        return self._available

    def get_unavailable_reason(self) -> str:
        return self._unavail_reason

    def _detect(self) -> bool:
        """Override to add extra checks beyond CLI resolution."""
        self._cli_path = resolve_cli(self.cli_command, self._cli_path_override())
        if self._cli_path is None:
            self._unavail_reason = f"'{self.cli_command}' not found on PATH"
            return False
        return True

    def _cli_path_override(self) -> str:
        """Optional explicit CLI path from module config (subclasses set section)."""
        return ""

    def _resolve_executable(self) -> str:
        """
        Return an absolute path to the CLI, resolving lazily if a probe hasn't
        run yet.  Falls back to the bare command name as a last resort so the
        subprocess can still surface a clear FileNotFoundError.
        """
        if not self._cli_path:
            self._cli_path = resolve_cli(self.cli_command, self._cli_path_override())
        return self._cli_path or self.cli_command

    # ── prompt call ──────────────────────────────────────────────────────────

    def call(
        self,
        prompt: str,
        timeout: int = 120,
        resume_session_id: Optional[str] = None,
    ) -> dict:
        """
        Send *prompt* to the AI and return:
            {"response": str, "error": None, "backend_session_id": str|None} on success
            {"response": None, "error": str, "backend_session_id": None} on failure
        """
        raise NotImplementedError

    # ── metadata ─────────────────────────────────────────────────────────────

    def get_info(self) -> dict:
        """Return display info for the status bar."""
        return {
            "provider": self.display_name,
            "model":    "default",
            "status":   "Connected" if self.is_available() else "Not Available",
            "note":     "CLI-based — no API key required",
        }

    # ── helpers ───────────────────────────────────────────────────────────────

    def _run(self, cmd: list[str], stdin_text: Optional[str] = None,
             timeout: int = 120) -> dict:
        """Shared subprocess runner used by concrete backends."""
        try:
            console_print(
                f"[{self.name}] calling: {' '.join(cmd[:3])}... "
                f"(prompt {len(stdin_text or '')} chars, timeout {timeout}s)"
            )
            result = subprocess.run(
                cmd,
                input=stdin_text,
                capture_output=True,
                text=True,
                timeout=timeout,
            )
            if result.returncode == 0:
                return {
                    "response": result.stdout.strip(),
                    "error": None,
                    "backend_session_id": None,
                }
            err = result.stderr.strip() or f"exit code {result.returncode}"
            console_print(f"[{self.name}] error: {err}")
            return {
                "response": None,
                "error": f"{self.display_name} error: {err}",
                "backend_session_id": None,
            }

        except subprocess.TimeoutExpired:
            msg = f"{self.display_name} timed out after {timeout}s"
            console_print(f"[{self.name}] {msg}")
            return {"response": None, "error": msg, "backend_session_id": None}
        except FileNotFoundError:
            msg = f"{self.display_name} CLI not found ({self.cli_command})"
            return {"response": None, "error": msg, "backend_session_id": None}
        except Exception as exc:
            msg = f"{self.display_name} unexpected error: {exc}"
            console_print(f"[{self.name}] {msg}")
            return {"response": None, "error": msg, "backend_session_id": None}

    @staticmethod
    def _parse_json_payload(raw: str) -> tuple[str, Optional[str]]:
        """Extract text response and optional session id from JSON CLI output."""
        try:
            payload: Any = json.loads(raw)
        except json.JSONDecodeError:
            return raw, None
        if isinstance(payload, dict):
            text = (
                payload.get("result")
                or payload.get("response")
                or payload.get("content")
                or payload.get("text")
            )
            if text is None and payload.get("message"):
                text = payload.get("message")
            sid = payload.get("session_id") or payload.get("chat_id") or payload.get("id")
            if isinstance(text, str) and text.strip():
                return text.strip(), str(sid) if sid else None
        return raw, None


# ── Registry ──────────────────────────────────────────────────────────────────

class AIBackendRegistry:
    """
    Registers all known AI backends.  Detection is *lazy* — no subprocess
    or network calls happen until check_one() is called explicitly.

    Usage:
        registry = AIBackendRegistry()
        names    = registry.list_all_names()    # all configured backends
        backend  = registry.get("claude")
        ok       = registry.check_one("claude") # fires actual probe
    """

    def __init__(self):
        from ai_query.backends.claude_cli  import ClaudeCliBackend
        from ai_query.backends.cursor_backend import CursorBackend
        from ai_query.backends.codex_backend  import CodexBackend

        # Ordered preference: fastest / most reliable first.
        # NOTE: instantiation MUST be cheap — no subprocess, no I/O.
        self._all: list[AIBackend] = [
            ClaudeCliBackend(),
            CursorBackend(),
            CodexBackend(),
        ]
        self._by_name: dict[str, AIBackend] = {b.name: b for b in self._all}

    # ── enumeration (no probing) ─────────────────────────────────────────────

    def list_all_names(self) -> list[str]:
        """Return ALL configured backend names — does not probe."""
        return [b.name for b in self._all]

    def list_all_backends(self) -> list[AIBackend]:
        return list(self._all)

    def get(self, name: str) -> Optional[AIBackend]:
        return self._by_name.get(name)

    # ── on-demand probing ────────────────────────────────────────────────────

    def check_one(self, name: str, force: bool = False) -> bool:
        """Run the availability probe for a single backend (explicit user action)."""
        b = self._by_name.get(name)
        if not b:
            return False
        return b.check_availability(force=force)

    def detect_all(self) -> None:
        """
        Eagerly probe every backend.  Kept for headless CLI / debugging only —
        the GUI does NOT call this at startup anymore.
        """
        console_print("\n=== AI Backend Detection ===")
        for backend in self._all:
            ok = backend.check_availability()
            console_print(
                f"  {'✓' if ok else '✗'} {backend.display_name:<18} "
                f"({'available' if ok else backend.get_unavailable_reason() or 'not found'})"
            )
        console_print("=" * 30 + "\n")

    # ── back-compat helpers (still lazy) ─────────────────────────────────────

    def available_names(self) -> list[str]:
        """Return names of backends already verified available (no new probe)."""
        return [b.name for b in self._all if b.is_available()]

    def available_backends(self) -> list[AIBackend]:
        return [b for b in self._all if b.is_available()]

    def get_default_name(self) -> str:
        """
        Return the configured default backend name (no probing).
        Returns empty string if config says 'auto'.
        """
        preferred = mc.get("ai", "default_backend", default="auto").strip()
        if preferred and preferred != "auto" and preferred in self._by_name:
            return preferred
        return ""
