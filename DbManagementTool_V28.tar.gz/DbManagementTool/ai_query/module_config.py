"""Loader for the AI Query module's config.ini (independently shippable)."""

from __future__ import annotations

from pathlib import Path

from common.config.module_ini import ModuleIniConfig

_DIR = Path(__file__).resolve().parent

DEFAULTS: dict[str, dict[str, str]] = {
    "ai": {
        "default_backend": "auto",
        "mask_pii": "true",
        "max_sessions": "20",
    },
    "ai.claude": {
        "cli_path": "",
        "cli_test_timeout": "5",
        "timeout": "120",
        "simple_query_timeout": "120",
        "complex_query_timeout": "180",
        "followup_timeout": "180",
        "max_output_tokens": "4000",
    },
    "ai.cursor": {"model": "auto", "timeout": "60"},
    "ai.codex": {"cli_path": "", "model": "", "timeout": "120"},
    "ai.cache": {
        "max_tables_fetch": "50",
        "max_tables_detailed": "10",
        "max_tables_display": "100",
        "max_constraints_display": "50",
        "max_indexes_display": "50",
        "top_tables_count": "15",
        "max_users_roles_display": "15",
    },
    "ui.ai_query": {
        "auto_execute_ai_loop": "false",
        "auto_execute_summary_sql": "false",
        "auto_loop_max_iterations": "5",
        "default_sql_mode": "summary",
        "sql_execution_rules": "",
    },
    "ai.limits": {"max_stored_sessions": "0"},
}

_cfg = ModuleIniConfig(_DIR, defaults=DEFAULTS)

get = _cfg.get
get_int = _cfg.get_int
get_float = _cfg.get_float
get_bool = _cfg.get_bool
set_value = _cfg.set_value
restore_defaults = _cfg.restore_defaults
reload = _cfg.reload
config_path = _cfg.config_path
live_path = _cfg.live_path
