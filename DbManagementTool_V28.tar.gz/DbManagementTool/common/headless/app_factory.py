"""
Assemble FastAPI apps for module-only or full-tool builds.

Core routes always use :class:`CoreDBService` (or any object with the same
surface). Module routers are mounted from manifests in ``core.modules``.
"""

from __future__ import annotations

import hmac
import os
from datetime import datetime
from typing import Any, Optional

from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, RedirectResponse
from pydantic import BaseModel, Field

from common.config_loader import (
    get_api_cors_origins,
    get_api_max_body_bytes,
    get_project_version,
)
from common.core import modules as _modules

try:
    from dotenv import load_dotenv as _load_dotenv

    _load_dotenv()
except Exception:
    pass


# Ensure storage layout / pending migration is in place before any service
# instance is constructed (CoreDBService touches ConnectionManager which
# touches the keys/connections subtree).
try:
    from common import paths as _paths

    _paths.bootstrap()
except Exception:
    pass


class SSHTunnelSpec(BaseModel):
    ssh_host: str = Field(..., min_length=1, max_length=512, examples=["bastion.example.com"])
    ssh_user: str = Field("", max_length=256, examples=["ubuntu"])
    ssh_port: int = Field(22, ge=1, le=65535, examples=[22])
    ssh_password: str = Field("", max_length=4096)
    ssh_key_file: str = Field("", max_length=1024, examples=["/home/me/.ssh/id_rsa"])


class ConnectionCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=128, examples=["my_mysql"])
    db_type: str = Field(..., min_length=1, max_length=64, examples=["MySQL"])
    host: str = Field(..., min_length=1, max_length=512, examples=["localhost"])
    port: str = Field("", max_length=16, examples=["3306"])
    user: str = Field(..., min_length=1, max_length=256, examples=["root"])
    password: str = Field("", max_length=4096, examples=["secret"])
    database: str = Field("", max_length=512, examples=["mydb"])
    service: str = Field("", max_length=512, examples=[""])
    # Optional: reach the database through an SSH tunnel. host/port above are
    # the database endpoint as seen from the SSH host (often localhost).
    ssh_tunnel: Optional[SSHTunnelSpec] = Field(None)


class QueryRequest(BaseModel):
    connection: str = Field(..., min_length=1, max_length=128, examples=["my_mysql"])
    sql: str = Field(..., min_length=1, max_length=1_000_000, examples=["SELECT 1"])


class MultiQueryRequest(BaseModel):
    connection: str = Field(..., min_length=1, max_length=128, examples=["my_mysql"])
    sql: str = Field(
        ...,
        min_length=1,
        max_length=1_000_000,
        examples=["CREATE TABLE t(id INT); INSERT INTO t VALUES (1); SELECT * FROM t;"],
        description="Multi-statement SQL; split on top-level ';'",
    )


class AutocommitRequest(BaseModel):
    enabled: bool = Field(..., examples=[True])


class TableExportRequest(BaseModel):
    table: str = Field(..., min_length=1, max_length=512, examples=["customers"])
    output_path: str = Field(..., min_length=1, max_length=4096, examples=["/tmp/customers.csv"])
    format: str = Field("csv", max_length=16, examples=["csv", "json"])
    limit: int | None = Field(None, examples=[1000])


class CsvImportRequest(BaseModel):
    file_path: str = Field(..., min_length=1, max_length=4096, examples=["/tmp/customers.csv"])
    table: str | None = Field(None, max_length=512, examples=["customers"])
    create_table: bool = Field(True, examples=[True])
    chunk_size: int = Field(500, examples=[500])


class DashboardLayoutRequest(BaseModel):
    rows: list = Field(
        ...,
        description="2-column grid: list of rows, each a list of panel ids "
                    "or null. Unknown panel ids are rejected.",
        examples=[[["connections", "monitor"], ["ai", "schema"],
                   ["sql_editor", "objects"]]],
        min_length=1,
    )


def _error(detail: str, status: int = 400):
    raise HTTPException(status_code=status, detail=detail)


def _env_int(name: str, default: int, low: int, high: int) -> int:
    try:
        value = int(os.environ.get(name, ""))
    except ValueError:
        return default
    return max(low, min(high, value))


def _public_path(path: str) -> bool:
    return (
        path in {"/", "/api", "/api/health", "/openapi.json"}
        or path.startswith("/docs")
        or path.startswith("/redoc")
    )


def _install_production_middlewares(app: FastAPI) -> None:
    api_key = os.environ.get("DBTOOL_API_KEY", "").strip()
    # Pre-encode once; compare in bytes so hmac.compare_digest works on any
    # supplied header value (str/bytes-safe via .encode below).
    api_key_bytes = api_key.encode("utf-8")
    configured_max_body = get_api_max_body_bytes(default=10 * 1024 * 1024)
    max_body = _env_int(
        "DBTOOL_API_MAX_BODY_BYTES",
        configured_max_body,
        1024,
        100 * 1024 * 1024,
    )

    @app.middleware("http")
    async def _guard_request(request: Request, call_next):
        content_length = request.headers.get("content-length")
        if content_length:
            try:
                if int(content_length) > max_body:
                    return JSONResponse(
                        {"detail": f"Request body too large (max {max_body} bytes)."},
                        status_code=413,
                    )
            except ValueError:
                return JSONResponse({"detail": "Invalid Content-Length header."}, status_code=400)

        if api_key and not _public_path(request.url.path):
            supplied = request.headers.get("x-api-key", "")
            auth = request.headers.get("authorization", "")
            if auth.lower().startswith("bearer "):
                supplied = auth[7:].strip()
            # Constant-time comparison: defeats timing side-channels even if a
            # remote attacker can measure response latency. compare_digest is
            # safe for unequal lengths (it still runs in constant time over
            # the shorter input and returns False).
            try:
                supplied_bytes = supplied.encode("utf-8")
            except (AttributeError, UnicodeEncodeError):
                supplied_bytes = b""
            if not hmac.compare_digest(supplied_bytes, api_key_bytes):
                return JSONResponse({"detail": "Unauthorized."}, status_code=401)
        return await call_next(request)


def mount_core_routes(app: FastAPI, svc: Any) -> None:
    """Register always-on core routes (connections, query, objects, config)."""

    @app.get("/", include_in_schema=False)
    def root():
        return RedirectResponse(url="/docs")

    @app.get("/api", tags=["Health"])
    def api_index():
        return {
            "service": app.title,
            "version": app.version,
            "docs": "/docs",
            "openapi": "/openapi.json",
            "health": "/api/health",
            "modules": "/api/modules",
        }

    @app.get("/api/health", tags=["Health"])
    def health():
        return {
            "status": "ok",
            "timestamp": datetime.now().isoformat(),
            "service": app.title,
        }

    @app.get("/api/modules", tags=["Health"])
    def modules_status():
        return _modules.status()

    @app.get("/api/connections", tags=["Connections"])
    def list_connections():
        return svc.list_connections()

    @app.post("/api/connections", tags=["Connections"], status_code=201)
    def create_connection(body: ConnectionCreate):
        result = svc.add_connection(
            name=body.name,
            db_type=body.db_type,
            host=body.host,
            port=body.port,
            user=body.user,
            password=body.password,
            database=body.database,
            service=body.service,
            ssh_tunnel=body.ssh_tunnel.model_dump() if body.ssh_tunnel else None,
        )
        if not result["ok"]:
            _error(result["message"])
        return result

    @app.delete("/api/connections/{name}", tags=["Connections"])
    def delete_connection(name: str):
        result = svc.remove_connection(name)
        if not result["ok"]:
            _error(result["message"], 404)
        return result

    @app.post("/api/connections/{name}/test", tags=["Connections"])
    def test_connection(name: str):
        result = svc.test_connection(name)
        if not result["ok"]:
            _error(result["message"])
        return result

    @app.get("/api/connections/active", tags=["Connections"])
    def list_active_connections():
        """Currently-open (cached) connections — mirrors the UI's Active list."""
        if not hasattr(svc, "list_active_connections"):
            return []
        return svc.list_active_connections()

    @app.post("/api/connections/{name}/open", tags=["Connections"])
    def open_connection(name: str):
        """Open (or reuse) a cached connection so subsequent queries are warm."""
        if not hasattr(svc, "open_connection"):
            _error("open_connection not supported by this service.", 501)
        result = svc.open_connection(name)
        if not result["ok"]:
            _error(result["message"])
        return result

    @app.post("/api/connections/{name}/close", tags=["Connections"])
    def close_connection(name: str):
        """Close one cached connection (does not delete the saved profile)."""
        if not hasattr(svc, "close_connection"):
            _error("close_connection not supported by this service.", 501)
        result = svc.close_connection(name)
        if not result["ok"]:
            _error(result["message"], 404)
        return result

    @app.post("/api/connections/close-all", tags=["Connections"])
    def close_all_connections():
        """Close every cached connection."""
        if not hasattr(svc, "close_all_connections"):
            _error("close_all_connections not supported by this service.", 501)
        result = svc.close_all_connections()
        if not result["ok"]:
            _error(result["message"])
        return result

    @app.post("/api/query", tags=["SQL"])
    def execute_query(body: QueryRequest):
        result = svc.execute(body.connection, body.sql)
        if result.get("error"):
            _error(result["error"])
        return result

    @app.post("/api/query/multi", tags=["SQL"])
    def execute_query_multi(body: MultiQueryRequest):
        """Split *sql* on ``;`` and execute each statement serially."""
        if not hasattr(svc, "execute_multi"):
            _error("execute_multi not supported by this service.", 501)
        result = svc.execute_multi(body.connection, body.sql)
        # Even on partial failure we return the full payload so callers can
        # inspect which statements succeeded before the failure.
        return result

    @app.post("/api/query/{connection}/cancel", tags=["SQL"])
    def cancel_query(connection: str):
        """Send a cancel signal to a currently-running query on *connection*."""
        if not hasattr(svc, "cancel_query"):
            _error("cancel_query not supported by this service.", 501)
        result = svc.cancel_query(connection)
        if not result["ok"]:
            _error(result["message"], 404)
        return result

    @app.get("/api/query/{connection}/autocommit", tags=["SQL"])
    def get_autocommit(connection: str):
        """Return the live autocommit state of *connection*."""
        if not hasattr(svc, "get_autocommit"):
            _error("get_autocommit not supported by this service.", 501)
        result = svc.get_autocommit(connection)
        if not result["ok"]:
            _error(result["message"], 404)
        return result

    @app.put("/api/query/{connection}/autocommit", tags=["SQL"])
    def set_autocommit(connection: str, body: AutocommitRequest):
        """Toggle autocommit on *connection*."""
        if not hasattr(svc, "set_autocommit"):
            _error("set_autocommit not supported by this service.", 501)
        result = svc.set_autocommit(connection, body.enabled)
        if not result["ok"]:
            _error(result["message"], 400)
        return result

    @app.post("/api/query/{connection}/commit", tags=["SQL"])
    def commit_tx(connection: str):
        """Commit the current transaction on *connection*."""
        if not hasattr(svc, "commit"):
            _error("commit not supported by this service.", 501)
        result = svc.commit(connection)
        if not result["ok"]:
            _error(result["message"], 404)
        return result

    @app.post("/api/query/{connection}/rollback", tags=["SQL"])
    def rollback_tx(connection: str):
        """Roll back the current transaction on *connection*."""
        if not hasattr(svc, "rollback"):
            _error("rollback not supported by this service.", 501)
        result = svc.rollback(connection)
        if not result["ok"]:
            _error(result["message"], 404)
        return result

    @app.get("/api/objects/{connection}", tags=["Objects"])
    def get_objects(
        connection: str,
        type: str = Query(
            "tables",
            description="Object type alias (tables, views, procs, … — engine-dependent)",
        ),
    ):
        items = svc.get_objects(connection, type)
        if items and isinstance(items[0], dict) and "error" in items[0]:
            _error(items[0]["error"])
        return {"connection": connection, "type": type, "items": items, "count": len(items)}

    @app.get("/api/objects/{connection}/sample", tags=["Objects"])
    def sample_table(
        connection: str,
        table: str = Query(..., description="Table or collection name"),
        limit: int = Query(5, ge=1, le=1000),
    ):
        """Return up to *limit* sample rows for *table*."""
        if not hasattr(svc, "sample_table"):
            _error("sample_table not supported by this service.", 501)
        result = svc.sample_table(connection, table, limit)
        if result.get("error"):
            _error(result["error"])
        return result

    @app.get("/api/objects/{connection}/count", tags=["Objects"])
    def count_table(connection: str, table: str = Query(...)):
        """Return ``{table, count}`` for *table*."""
        if not hasattr(svc, "count_table"):
            _error("count_table not supported by this service.", 501)
        result = svc.count_table(connection, table)
        if result.get("error"):
            _error(result["error"])
        return result

    @app.post("/api/objects/{connection}/export", tags=["Objects"])
    def export_table(connection: str, body: TableExportRequest):
        """Dump *table* to *output_path* on the server filesystem as CSV/JSON."""
        if not hasattr(svc, "export_table"):
            _error("export_table not supported by this service.", 501)
        result = svc.export_table(
            connection, body.table, body.output_path,
            fmt=body.format, limit=body.limit,
        )
        if not result["ok"]:
            _error(result["message"])
        return result

    @app.post("/api/objects/{connection}/import-csv", tags=["Objects"])
    def import_csv_to_table(connection: str, body: CsvImportRequest):
        """Bulk-load a CSV file into a target table (creates it if missing)."""
        if not hasattr(svc, "import_csv_to_table"):
            _error("import_csv_to_table not supported by this service.", 501)
        result = svc.import_csv_to_table(
            connection, body.file_path,
            table=body.table,
            create_table=body.create_table,
            chunk_size=body.chunk_size,
        )
        if not result["ok"]:
            _error(result["message"])
        return result

    @app.get("/api/config", tags=["Config"])
    def config_show(section: str = Query("", description="Limit to one section; blank = all")):
        r = svc.show_config(section=section or None)
        if r.get("error"):
            _error(r["error"])
        return r

    # ------------------------------------------------------------------
    # Read-only curated settings. Secrets are ALWAYS redacted and never
    # returned. Writes are intentionally NOT exposed over the API — change
    # settings via the Settings UI or the `config set` CLI on the host.
    # ------------------------------------------------------------------
    @app.get("/api/config/settings", tags=["Config"])
    def config_settings(
        group: str = Query("", description="Filter by group name (blank = all)"),
        grouped: bool = Query(False, description="Return settings grouped by category"),
    ):
        """Curated, self-describing settings with current values (secrets redacted)."""
        from common.config import settings_service as _S

        if grouped:
            data = _S.grouped(redact=True)
            if group:
                data = {group: data.get(group, [])}
            return {"groups": data, "writable": False,
                    "note": "Read-only. Edit settings via the Settings UI or "
                            "`config set` CLI on the host."}
        rows = _S.describe_all(redact=True)
        if group:
            rows = [r for r in rows if r["group"].lower() == group.lower()]
        return {"settings": rows, "count": len(rows), "writable": False}

    @app.get("/api/config/settings/{spec_id}", tags=["Config"])
    def config_setting(spec_id: str):
        """One setting's description + current value (secret redacted)."""
        from common.config import settings_service as _S

        spec = _S.find(spec_id)
        if spec is None:
            _error(f"Unknown setting '{spec_id}'.", 404)
        return _S.describe(spec, redact=True)

    @app.get("/api/databases/types", tags=["Databases"])
    def databases_types():
        return svc.list_db_types()

    @app.get("/api/databases/ops", tags=["Databases"])
    def databases_ops(type: str = Query(..., description="DB engine, e.g. MySQL")):
        return svc.list_db_ops(type)

    @app.get("/api/dashboard", tags=["Dashboard"])
    def dashboard_snapshot():
        from common.dashboard.service import DashboardService

        mod_status = _modules.status()
        active = getattr(svc, "_active", {})

        def _active_map():
            return active if isinstance(active, dict) else {}

        dash = DashboardService(
            get_active_connections=_active_map,
            get_saved_connections=lambda: svc.list_connections(),
            has_schema=mod_status.get("migrator", {}).get("installed", False),
            has_ai=mod_status.get("ai", {}).get("installed", False),
            has_monitor=mod_status.get("monitor", {}).get("installed", False),
        )
        return dash.collect()

    # ------------------------------------------------------------------
    # Phase 7 — app-level: cache clearing, dashboard layout, shortcuts.
    # ------------------------------------------------------------------

    @app.post("/api/app/clear-caches", tags=["App"])
    def app_clear_caches():
        """Clear every in-process cache we know how to clear (AI schema/context, ...)."""
        from common.headless import app_service as appsvc

        return appsvc.clear_all_caches(svc)

    @app.get("/api/dashboard/layout", tags=["Dashboard"])
    def app_get_layout():
        """Current 2-column dashboard grid plus the default-for-reset reference."""
        from common.headless import app_service as appsvc

        return appsvc.get_dashboard_layout()

    @app.post("/api/dashboard/layout/reset", tags=["Dashboard"])
    def app_reset_layout():
        """Reset the dashboard grid to the default layout."""
        from common.headless import app_service as appsvc

        return appsvc.reset_dashboard_layout()

    @app.put("/api/dashboard/layout", tags=["Dashboard"])
    def app_save_layout(body: DashboardLayoutRequest):
        """Save a new dashboard grid (validated against the known panel ids)."""
        from common.headless import app_service as appsvc

        r = appsvc.save_dashboard_layout(body.rows)
        if not r["ok"]:
            _error(r["message"])
        return r

    @app.get("/api/app/shortcuts", tags=["App"])
    def app_shortcuts(section: str = Query("", description="Optional section filter")):
        """Curated keyboard-shortcut reference for the UI."""
        from common.headless import app_service as appsvc

        return appsvc.list_shortcuts(section or None)


def _composite_full_service(core: Any):
    """Build a composite service that exposes every installed module's bridge.

    Falls back to the bare *core* if no module bridges are discoverable. This
    is what backs the **full** API (``module_key=None``) so endpoints like
    ``/api/migrator/convert`` resolve their service methods correctly instead of
    falling through to ``CoreDBService`` (which doesn't carry them).

    Idempotent — if *core* is already a CompositeService the original is
    returned, so callers can safely wrap a service twice without duplicating
    the module bridges.
    """
    from common.core.standalone_runner import _MODULE_SERVICE_FACTORIES, _import_factory
    from common.headless.composite import CompositeService, composite_service

    if isinstance(core, CompositeService):
        return core

    bridges: list[Any] = []
    for module_key, factory_path in _MODULE_SERVICE_FACTORIES.items():
        manifest = _modules.get(module_key)
        if manifest is None:
            continue
        try:
            built = _import_factory(factory_path)(core)
            # The module factory may return a composite itself; in that case
            # only keep its module-side layer so we don't shadow the live core.
            mods = getattr(built, "_modules", None)
            if mods:
                bridges.extend(mods)
            else:
                bridges.append(built)
        except Exception as exc:  # pragma: no cover
            import logging

            logging.getLogger(__name__).warning(
                "Could not build bridge for module '%s': %s", module_key, exc
            )
    if not bridges:
        return core
    return composite_service(core, *bridges)


def mount_module_routers(
    app: FastAPI,
    svc: Any,
    *,
    module_key: Optional[str] = None,
) -> list[str]:
    """Mount one module (standalone) or all installed modules (full tool)."""
    mounted: list[str] = []
    if module_key is not None:
        manifest = _modules.get(module_key)
        if manifest is None or manifest.build_router is None:
            return mounted
        try:
            app.include_router(manifest.build_router(svc))
            mounted.append(module_key)
        except Exception as exc:  # pragma: no cover
            import logging

            logging.getLogger(__name__).warning(
                "Could not mount module '%s' router: %s", module_key, exc
            )
        return mounted

    # Full app: build a single composite so every router sees one service that
    # carries the core + every module's methods.
    full_svc = _composite_full_service(svc)
    for command, manifest in _modules.discover().items():
        if manifest.build_router is None:
            continue
        try:
            app.include_router(manifest.build_router(full_svc))
            mounted.append(command)
        except Exception as exc:  # pragma: no cover
            import logging

            logging.getLogger(__name__).warning(
                "Could not mount module '%s' router: %s", command, exc
            )
    return mounted


def create_app(
    *,
    module_key: Optional[str] = None,
    title: Optional[str] = None,
    svc: Any = None,
) -> FastAPI:
    """
    Build a FastAPI application.

    * ``module_key=None`` — core + every installed module router.
    * ``module_key='migrator'|'ai'|'monitor'`` — core + that module only.
    """
    if module_key is not None:
        manifest = _modules.get(module_key)
        default_title = manifest.title if manifest else module_key
        description = f"Core + {default_title} module"
    else:
        default_title = "DbManagementTool API"
        description = "Headless REST API — core + installed modules."

    if svc is None:
        from common.headless.db_service import CoreDBService

        svc = CoreDBService()

    # When running the full app, layer every installed module's bridge over
    # the bare core service so the core routes (e.g. /api/app/clear-caches,
    # /api/connections/{n}/open) can resolve module-side methods like
    # `clear_ai_cache`. Single-module apps stay on the bare core.
    if module_key is None:
        svc = _composite_full_service(svc)

    app = FastAPI(
        title=title or default_title,
        description=description,
        version=get_project_version(),
        docs_url="/docs",
        redoc_url="/redoc",
    )
    origins_raw = os.environ.get("DBTOOL_API_CORS_ORIGINS", get_api_cors_origins()).strip()
    origins = ["*"] if origins_raw == "*" else [
        o.strip() for o in origins_raw.split(",") if o.strip()
    ]
    app.add_middleware(
        CORSMiddleware,
        allow_origins=origins or ["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )
    _install_production_middlewares(app)

    mount_core_routes(app, svc)
    mount_module_routers(app, svc, module_key=module_key)
    return app
