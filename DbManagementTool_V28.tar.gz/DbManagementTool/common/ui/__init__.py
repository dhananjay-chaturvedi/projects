"""Shared UI theme, widgets, and desktop shell — ship with ``common/`` in every module build."""

from common.ui.theme import ColorTheme, default_ui_font, default_ui_mono
from common.ui.widgets import (
    bind_canvas_mousewheel,
    create_horizontal_scrollable,
    disable_combobox_mousewheel,
    make_collapsible_section,
)
from common.ui.launcher import launch_desktop_ui

__all__ = [
    "ColorTheme",
    "default_ui_font",
    "default_ui_mono",
    "bind_canvas_mousewheel",
    "create_horizontal_scrollable",
    "disable_combobox_mousewheel",
    "make_collapsible_section",
    "launch_desktop_ui",
]
