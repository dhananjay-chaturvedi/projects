"""Operational dashboard (core — module-aware)."""

from common.dashboard.dashboard_ui import DashboardUI
from common.dashboard.service import DashboardService

__all__ = ["DashboardUI", "DashboardService"]
