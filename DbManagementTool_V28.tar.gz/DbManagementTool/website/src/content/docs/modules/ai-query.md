---
title: AI Query Assistant
description: Natural-language to SQL using Claude, Cursor, or Codex CLIs. Multi-tab sessions, cross-tab references, SQL execution rules.
sidebar:
  order: 2
---

Ask questions in plain English (or any language the chosen backend
supports). The assistant generates SQL, runs it against your connection,
and returns rows plus a natural-language explanation.

## Supported backends

| Backend | Config section (`ai_query/config.ini`) | Install |
|---------|------------------------------------------|---------|
| Claude | `[ai.claude]` | <https://claude.ai/download> |
| Cursor | `[ai.cursor]` | <https://cursor.com> |
| Codex | `[ai.codex]` | <https://github.com/openai/codex> |

All backends are **CLI-based** — no API keys needed. The assistant
reuses your existing CLI login session.

The `claude` and `codex` backends resolve their CLI from an optional
`cli_path` override, then `PATH`, then common install dirs
(`~/.local/bin`, `~/bin`, `~/.claude/local`, Homebrew, `/usr/local/bin`),
so they keep working when the app launches with a minimal GUI `PATH`:

```ini
[ai.claude]
cli_path =       # optional full path to the claude binary

[ai.codex]
cli_path =       # optional full path to the codex binary
```

## Pick a backend

```bash
python dbtool.py ai --list-backends
# claude  *  (default)
# cursor
# codex
```

Set in `ai_query/config.ini` (or use **AI Settings** on the tab):

```ini
[ai]
default_backend = auto      # auto | claude | cursor | codex
```

```bash
python dbtool.py ai config show
python dbtool.py ai config set ai default_backend claude
```

`auto` picks the first available CLI.

## One-shot queries

```bash
python dbtool.py ai --conn prod "count rows in users"

python dbtool.py ai --conn prod --backend cursor \
    "top 5 customers by revenue last 30 days"

python dbtool.py ai --conn prod --sql-mode strict_summary \
    "how many tables in this database?"
```

## SQL modes

| Mode | Behavior |
|------|----------|
| `strict_summary` | Only catalog / metadata SQL is allowed to auto-run. Fastest for "how many" / "what tables" questions. |
| `summary` *(default)* | Catalog-first; user-table SQL is allowed when needed for the answer. |
| `open` | No SQL scope restrictions. Use for analytical queries. |

`SQL execution rules` (LIMIT enforcement, EXPLAIN before multi-joins)
apply in Summary and Open modes — see [AI Query CLI](/cli/ai/) for
details.

## Multi-tab sessions

Sessions persist conversation state and SQL context. Each tab has its
own connection, backend, and history.

```bash
python dbtool.py ai session new --conn prod --backend claude
python dbtool.py ai session ask --session tab1 "count rows in users"
python dbtool.py ai session follow-up --session tab1 "add a date filter"
python dbtool.py ai session list
python dbtool.py ai session save
python dbtool.py ai session load
python dbtool.py ai session close --session tab1
```

Sessions are stored at `~/.dbassistant/session/ai/sessions.json`
(configurable). `max_stored_sessions` in `[ai.limits]`
(`ai_query/config.ini`) caps how many are kept on save
(`0` = keep all).

## Cross-tab references

```bash
python dbtool.py ai session ask --session tab1 \
    "@tab2 show top 5 customers"

python dbtool.py ai session cross --session tab1 \
    "talk to tab 3: count rows in orders"
```

Syntax recognized in chat and CLI:

| Syntax | Meaning |
|--------|---------|
| `@tab2`, `tab 2`, `use tab 2` | Pull context from tab 2 into current tab |
| `talk to tab 3: ...` | Route to tab 3 — SQL runs on tab 3's connection |
| `use tab 2 and tab 4: ...` | Coordinate across the referenced tabs |

## REST API

```bash
# One-shot
curl -X POST -H "X-API-Key: $DBTOOL_API_KEY" \
     -H "Content-Type: application/json" \
     -d '{"connection":"prod","question":"count employees","sql_mode":"open"}' \
     "http://localhost:8000/api/ai/query"

# Session lifecycle
curl -X POST -H "X-API-Key: $DBTOOL_API_KEY" \
     -H "Content-Type: application/json" \
     -d '{"connection":"prod","backend":"claude","sql_mode":"summary"}' \
     "http://localhost:8000/api/ai/sessions"

curl -X POST -H "X-API-Key: $DBTOOL_API_KEY" \
     -H "Content-Type: application/json" \
     -d '{"message":"count rows in users"}' \
     "http://localhost:8000/api/ai/sessions/tab1/messages"

curl -X POST -H "X-API-Key: $DBTOOL_API_KEY" \
     "http://localhost:8000/api/ai/sessions/save"
```

## Programmatic

```python
from app.headless.db_service import DBService

svc = DBService()
print(svc.list_ai_backends())                       # ["claude*", "cursor", "codex"]
print(svc.ai_query("prod", "count rows in users"))  # {"sql": ..., "rows": [...], "explanation": ...}
```

## Options menu

| Option | Effect |
|--------|--------|
| Uninterrupted follow-ups | After each AI reply, keep refining until `SATISFIED: yes` or iteration limit |
| Auto-execute SQL queries | Runs SUMMARY_SQL automatically after each response |
| Strict summary mode | Catalog/metadata SQL only |
| Summary mode | Catalog-first; user-table SQL allowed when needed |
| Open mode | No SQL scope restrictions |
| Stop | Cancel running SQL or stop iteration loop |

Defaults are set in `ai_query/config.ini`:

```ini
[ui.ai_query]
auto_execute_ai_loop = false
auto_execute_summary_sql = false
auto_loop_max_iterations = 5
default_sql_mode = summary
```
