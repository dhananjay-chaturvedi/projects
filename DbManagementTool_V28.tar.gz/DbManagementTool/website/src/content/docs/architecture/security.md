---
title: Security model
description: Encryption, secret storage, API authentication, and hardening guidance.
sidebar:
  order: 4
---

DbAssistant treats every saved credential as sensitive.

## Encryption at rest

All saved DB and cloud connection profiles are encrypted with
[Fernet](https://cryptography.io/en/latest/fernet/) (AES-128 in CBC
mode with HMAC-SHA256).

```text
~/.dbassistant/keys/db.key          ← randomly generated on first run
~/.dbassistant/keys/cloud.key
~/.dbassistant/keys/monitor.key
```

Each key file is `0600` (owner read/write only). Connection files are
also `0600`.

## Key rotation

To rotate the DB encryption key:

1. Export connection list (`dbtool connections list --format json`)
2. Remove `~/.dbassistant/keys/db.key`
3. Re-add each connection with `dbtool connections add ...`

A future release will ship an automated rotation command.

## REST API authentication

Set `DBTOOL_API_KEY` in `.env` (or as an environment variable):

```dotenv
DBTOOL_API_KEY=super-long-random-string-at-least-32-chars
```

Every `/api/*` request must include:

```text
X-API-Key: super-long-random-string-at-least-32-chars
```

The comparison uses
[`hmac.compare_digest`](https://docs.python.org/3/library/hmac.html#hmac.compare_digest)
to prevent timing attacks. Missing or wrong key → `401 Unauthorized`.

If `DBTOOL_API_KEY` is unset, the API runs in open mode — only use
that bound to `127.0.0.1` behind your own auth proxy.

## Request size limits

The API rejects request bodies larger than 1 MB by default
(configurable). This prevents memory exhaustion from oversized SQL
strings or JSON payloads.

## CORS

The REST API allows all origins by default for development convenience.
Before exposing it on a network, restrict origins in
`common/headless/app_factory.py`:

```python
app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://your-frontend.example.com"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

## Daemon control

`/api/daemon/start` and `/api/daemon/stop` are intentionally **not
exposed over HTTP**. Lifecycle is CLI-only:

```bash
python dbtool.py daemon start
python dbtool.py daemon stop
```

`GET /api/daemon/status` is available for read-only monitoring.

## Cloud login

`POST /api/cloud/connections/{name}/login` shells out to `aws`, `az`,
or `gcloud` and opens a browser **on the host running the API**. It is
intended for local/developer use only. For production cloud auth,
configure environment-based credentials (IAM roles, service accounts,
Azure managed identity).

## Logging

`mask_sensitive_in_logs = true` in `config.ini` redacts passwords,
tokens, and connection strings from log lines.

## Recommended hardening checklist

- Set `DBTOOL_API_KEY` to a 64-character random string
- Run the API on `127.0.0.1` behind a reverse proxy (nginx, Caddy) with TLS
- Restrict CORS to your front-end origin
- Keep `~/.dbassistant/` on encrypted disk (FileVault / dm-crypt)
- Audit `~/.dbassistant/keys/` permissions (`0600`)
- Use OS-level auth (AWS profiles, `az login`, `gcloud auth`) instead
  of storing static cloud keys whenever possible
