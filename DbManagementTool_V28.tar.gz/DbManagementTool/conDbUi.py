"""Shim — launch shared desktop shell from ``common.ui``."""
from common.ui.master_shell import main

if __name__ == "__main__":
    main()
