"""
Schema conversion bridge for full-tool service composition.

Schema logic lives in :class:`schema_converter.service.SchemaService`; this
thin adapter exposes ``convert_schema`` / ``dump_schema`` on a core service.
"""

from __future__ import annotations

from typing import Any


def make_service(core=None):
    """Core + schema composite for module-only CLI/API."""
    from common.headless.composite import composite_service
    from common.headless.db_service import CoreDBService

    core = core or CoreDBService()
    return composite_service(core, SchemaBridge(core))


class SchemaBridge:
    """Expose schema convert/dump on a core connection service."""

    def __init__(self, core: Any):
        self._core = core
        self._schema = None

    def _schema_service(self):
        if self._schema is None:
            from schema_converter import SchemaService

            self._schema = SchemaService(connect=self._core.get_manager)
        return self._schema

    @staticmethod
    def _build_transfer_options(
        *,
        where: str = "",
        limit: int | None = None,
        columns: str = "",
        column_map: str = "",
        continue_on_error: bool = False,
        overflow_policy: str = "",
        null_policy: str = "",
        bool_policy: str = "",
        timezone_policy: str = "",
        target_timezone: str = "",
        reset_sequences: bool = False,
        checkpoint: bool = False,
        report_path: str = "",
    ):
        """Merge per-run transfer flags onto saved migrator config defaults."""
        from schema_converter.transfer_options import (
            TransferOptions,
            merge_options,
            options_from_config,
        )
        from schema_converter.transfer_options import (
            parse_column_map,
            parse_columns,
        )

        override = TransferOptions(
            where=where or "",
            limit=limit,
            columns=parse_columns(columns),
            column_map=parse_column_map(column_map),
            continue_on_error=bool(continue_on_error),
            overflow_policy=overflow_policy or "fail",
            null_policy=null_policy or "keep",
            bool_policy=bool_policy or "auto",
            timezone_policy=timezone_policy or "preserve",
            target_timezone=target_timezone or "",
            reset_sequences=bool(reset_sequences),
            checkpoint=bool(checkpoint),
            report_path=report_path or "",
        )
        return merge_options(options_from_config(), override)

    def validate_migration(
        self,
        source_conn: str,
        target_conn: str,
        tables: list[str],
        *,
        target_db: str = "",
        prefix: str = "",
        suffix: str = "",
        type_map: str = "",
    ) -> dict:
        """Pre-migration dry-run validation report (G5). Read-only."""
        try:
            from schema_converter.migration_validation import validate_migration
            from schema_converter.table_naming import qualify_target_table
            from schema_converter.type_overrides import resolve_type_overrides

            src_mgr = self._core.get_manager(source_conn)
            tgt_mgr = self._core.get_manager(target_conn)
            overrides = resolve_type_overrides(type_map or None)
            pairs = [
                (t, qualify_target_table(t, target_db, prefix, suffix))
                for t in (tables or [])
                if str(t).strip()
            ]
            report = validate_migration(
                src_mgr, tgt_mgr, pairs, type_overrides=overrides
            )
            report["source_conn"] = source_conn
            report["target_conn"] = target_conn
            return report
        except Exception as exc:
            return {"ok": False, "error": str(exc), "tables": []}

    def convert_schema(
        self,
        source_conn: str,
        target_db_type: str,
        table: str,
        target_db: str = "",
        prefix: str = "",
        suffix: str = "",
        table_name_map: dict | None = None,
        type_map: str = "",
    ) -> dict:
        return self._schema_service().convert(
            source_conn, target_db_type, table,
            target_db=target_db, prefix=prefix, suffix=suffix,
            table_name_map=table_name_map,
            type_map=type_map,
        )

    def dump_schema(self, name: str, table: str | None = None) -> dict:
        return self._schema_service().dump(name, table)

    def compare_schema(
        self,
        source_conn: str,
        target_conn: str,
        table: str,
        target_table: str | None = None,
    ) -> dict:
        return self._schema_service().compare_schema(
            source_conn, target_conn, table, target_table
        )

    def compare_data(
        self,
        source_conn: str,
        target_conn: str,
        table: str,
        target_table: str | None = None,
        mode: str = "sample",
        sample_size: int | None = None,
    ) -> dict:
        return self._schema_service().compare_data(
            source_conn,
            target_conn,
            table,
            target_table=target_table,
            mode=mode,
            sample_size=sample_size,
        )

    def get_table_schema(self, name: str, table: str) -> dict:
        return self._core.get_table_schema(name, table)

    # ------------------------------------------------------------------
    # Parity additions (Phase 4) — batch convert, apply DDL on target,
    # transfer data, multi-table row counts and sample data.
    # ------------------------------------------------------------------

    def convert_schema_multi(
        self,
        source_conn: str,
        target_db_type: str,
        tables: list[str],
        target_db: str = "",
        prefix: str = "",
        suffix: str = "",
        type_map: str = "",
    ) -> dict:
        """Convert several tables in one call. Returns
        ``{error, target_type, tables: [{table, target_table, ddl, indexes_ddl,
        all_ddl, error, issues}], joined_ddl}``.

        When *target_db*/*prefix*/*suffix* are supplied, all target table names
        are qualified and a shared table-name map is passed to each conversion so
        cross-table references (foreign keys) resolve to the qualified names.
        """
        from schema_converter.table_naming import qualify_target_table

        name_map = {
            t: qualify_target_table(t, target_db, prefix, suffix)
            for t in (tables or [])
        }
        out: list[dict] = []
        for table in tables or []:
            r = self.convert_schema(
                source_conn, target_db_type, table,
                target_db=target_db, prefix=prefix, suffix=suffix,
                table_name_map=name_map,
                type_map=type_map,
            )
            out.append({
                "table": table,
                "target_table": r.get("target_table") or name_map.get(table, table),
                "ddl": r.get("ddl") or "",
                "indexes_ddl": r.get("indexes_ddl") or [],
                "all_ddl": r.get("all_ddl") or [],
                "issues": r.get("issues") or [],
                "error": r.get("error"),
            })
        joined_parts: list[str] = []
        for row in out:
            for part in row.get("all_ddl") or []:
                p = (part or "").strip()
                if p:
                    joined_parts.append(p)
        first_err = next((row["error"] for row in out if row.get("error")), None)
        return {
            "error": first_err,
            "target_type": target_db_type,
            "tables": out,
            "joined_ddl": "\n\n".join(joined_parts),
        }

    def apply_ddl_to_target(
        self,
        target_conn: str,
        ddl: str,
        stop_on_error: bool = True,
    ) -> dict:
        """Execute a (possibly multi-statement) DDL blob against *target_conn*.

        Mirrors the UI's "Create target schemas" step. Splits on ``;`` via the
        core's SQL splitter so multi-statement input is supported even when the
        driver itself doesn't. Returns ``{error, executed, failed,
        statements: [{sql, ok, error}]}``.
        """
        if not (ddl or "").strip():
            return {"error": "No DDL to apply.", "executed": 0,
                    "failed": 0, "statements": []}
        try:
            statements = self._core._split_sql_statements(ddl)
        except Exception:
            statements = [s for s in (ddl or "").split(";") if s.strip()]
        results: list[dict] = []
        executed = 0
        failed = 0
        first_err: str | None = None
        for stmt in statements:
            res = self._core.execute(target_conn, stmt)
            err = res.get("error")
            results.append({"sql": stmt, "ok": not err, "error": err})
            if err:
                failed += 1
                if first_err is None:
                    first_err = err
                if stop_on_error:
                    break
            else:
                executed += 1
        return {
            "error": first_err,
            "executed": executed,
            "failed": failed,
            "statements": results,
        }

    def transfer_data(
        self,
        source_conn: str,
        target_conn: str,
        table: str,
        target_table: str | None = None,
        batch_size: int | None = None,
        target_db: str = "",
        prefix: str = "",
        suffix: str = "",
        *,
        where: str = "",
        limit: int | None = None,
        columns: str = "",
        column_map: str = "",
        continue_on_error: bool = False,
        overflow_policy: str = "",
        null_policy: str = "",
        bool_policy: str = "",
        timezone_policy: str = "",
        target_timezone: str = "",
        reset_sequences: bool = False,
        checkpoint: bool = False,
        report_path: str = "",
    ) -> dict:
        """Copy rows from ``table`` on *source_conn* to ``target_table`` on
        *target_conn*. Mirrors the UI's "Transfer data only" button.

        If *target_table* is not given but *target_db*/*prefix*/*suffix* are, the
        target name is qualified the same way the UI does.

        Optional keyword arguments enable row filtering (G1), column
        subset/rename (G2), continue-on-error (G3), overflow policy (G4),
        null/bool normalization (G6), timezone handling (G7), sequence reset
        (G8), checkpoint/resume (G9) and a report artifact (G10).

        Returns ``{ok, rows_transferred, skipped, source_table, target_table,
        message}``.
        """
        if not target_table:
            from schema_converter.table_naming import qualify_target_table

            target_table = qualify_target_table(table, target_db, prefix, suffix)
        target_table = target_table or table
        try:
            src_mgr = self._core.get_manager(source_conn)
            tgt_mgr = self._core.get_manager(target_conn)
            from schema_converter.adapters import transfer_object, validate_migration_pair

            err = validate_migration_pair(
                src_mgr.db_type, tgt_mgr.db_type, operation="transfer"
            )
            if err:
                return {
                    "ok": False,
                    "rows_transferred": 0,
                    "source_table": table,
                    "target_table": target_table,
                    "message": err,
                }

            options = self._build_transfer_options(
                where=where,
                limit=limit,
                columns=columns,
                column_map=column_map,
                continue_on_error=continue_on_error,
                overflow_policy=overflow_policy,
                null_policy=null_policy,
                bool_policy=bool_policy,
                timezone_policy=timezone_policy,
                target_timezone=target_timezone,
                reset_sequences=reset_sequences,
                checkpoint=checkpoint,
                report_path=report_path,
            )
            checkpoint_store = None
            if options.checkpoint:
                from schema_converter.migration_report import CheckpointStore

                checkpoint_store = CheckpointStore(
                    CheckpointStore.default_path(source_conn, target_conn)
                )

            stats: dict = {}
            rows = transfer_object(
                src_mgr,
                tgt_mgr,
                table,
                target_table,
                batch_size=batch_size,
                options=options,
                checkpoint_store=checkpoint_store,
                stats_out=stats,
            )
            count = int(rows or 0)
            skipped = int(stats.get("skipped") or 0)
            if checkpoint_store is not None:
                checkpoint_store.clear(table, target_table)

            result = {
                "ok": True,
                "rows_transferred": count,
                "skipped": skipped,
                "errors": stats.get("error_count", 0),
                "source_table": table,
                "target_table": target_table,
                "message": (
                    f"Transferred {count} row(s) from {table} → {target_table}."
                    + (f" Skipped {skipped}." if skipped else "")
                ),
            }

            if options.report_path:
                from schema_converter.migration_report import MigrationReport

                report = MigrationReport(
                    options.report_path,
                    source_conn=source_conn,
                    target_conn=target_conn,
                )
                report.add_table(
                    {
                        "source_table": table,
                        "target_table": target_table,
                        "ok": True,
                        "rows_transferred": count,
                        "skipped": skipped,
                        "error_count": stats.get("error_count", 0),
                        "duration_seconds": stats.get("duration_seconds"),
                        "errors": (stats.get("errors") or [])[:50],
                    }
                )
                result["report_path"] = report.write()
            return result
        except Exception as exc:
            return {
                "ok": False,
                "rows_transferred": 0,
                "source_table": table,
                "target_table": target_table,
                "message": str(exc),
            }

    def transfer_data_multi(
        self,
        source_conn: str,
        target_conn: str,
        tables: list[str],
        *,
        batch_size: int | None = None,
        target_db: str = "",
        prefix: str = "",
        suffix: str = "",
        parallel: bool = False,
        workers: int | None = None,
        limit: int | None = None,
        column_map: str = "",
        continue_on_error: bool = False,
        overflow_policy: str = "",
        null_policy: str = "",
        bool_policy: str = "",
        timezone_policy: str = "",
        target_timezone: str = "",
        reset_sequences: bool = False,
        checkpoint: bool = False,
        report_path: str = "",
    ) -> dict:
        """Copy rows for multiple tables, optionally in parallel.

        Parallel workers open fresh, task-scoped source/target DB sessions
        through ``CoreDBService.open_session`` so transactions stay isolated and
        the cached connection for SQL Editor/API requests is not shared.

        Row filter (WHERE) and column subset are single-table only and are not
        accepted here. Column rename (``column_map``) and the row ``limit`` are
        applied to every table (a rename is a no-op for tables that lack a
        listed source column). Fixed-value policies (continue-on-error,
        overflow, null/bool, timezone, sequence reset) layer onto saved migrator
        config defaults.
        """
        try:
            from schema_converter import module_config
            from schema_converter.parallel_transfer import (
                build_transfer_specs,
                run_parallel_transfer,
            )
            from schema_converter.table_naming import qualify_target_table

            if not tables:
                return {"ok": False, "error": "No tables supplied.", "tables": []}
            worker_count = int(
                workers
                if workers is not None
                else module_config.get_int(
                    "schema.conversion", "parallel_workers", default=1
                )
            )
            if not parallel:
                worker_count = 1
            specs = build_transfer_specs(
                tables,
                lambda table: qualify_target_table(table, target_db, prefix, suffix),
            )

            options = self._build_transfer_options(
                limit=limit,
                column_map=column_map,
                continue_on_error=continue_on_error,
                overflow_policy=overflow_policy,
                null_policy=null_policy,
                bool_policy=bool_policy,
                timezone_policy=timezone_policy,
                target_timezone=target_timezone,
                reset_sequences=reset_sequences,
                checkpoint=checkpoint,
                report_path=report_path,
            )
            checkpoint_store = None
            if options.checkpoint:
                from schema_converter.migration_report import CheckpointStore

                checkpoint_store = CheckpointStore(
                    CheckpointStore.default_path(source_conn, target_conn)
                )

            def _open(core_name: str):
                if hasattr(self._core, "open_session"):
                    return self._core.open_session(core_name)
                # Fallback for custom test composites; not parallel-safe for real
                # use, but keeps legacy injected cores working in serial mode.
                return self._core.get_manager(core_name)

            result = run_parallel_transfer(
                source_conn,
                target_conn,
                specs,
                source_manager_factory=_open,
                target_manager_factory=_open,
                batch_size=batch_size,
                workers=worker_count,
                options=options,
                checkpoint_store=checkpoint_store,
            )
            result["source_conn"] = source_conn
            result["target_conn"] = target_conn
            result["parallel"] = bool(parallel and worker_count > 1)

            if options.report_path:
                from schema_converter.migration_report import MigrationReport

                report = MigrationReport(
                    options.report_path,
                    source_conn=source_conn,
                    target_conn=target_conn,
                )
                for row in result.get("tables") or []:
                    report.add_table(
                        {
                            "source_table": row.get("source_table"),
                            "target_table": row.get("target_table"),
                            "ok": row.get("ok"),
                            "rows_transferred": row.get("rows_transferred", 0),
                            "skipped": row.get("skipped", 0),
                            "error_count": row.get("error_count", 0),
                            "duration_seconds": row.get("duration_seconds"),
                            "source_count": row.get("source_count"),
                            "target_count": row.get("target_count"),
                            "error": row.get("error"),
                        }
                    )
                result["report_path"] = report.write()
            return result
        except Exception as exc:
            return {
                "ok": False,
                "error": str(exc),
                "tables": [],
                "successful": 0,
                "failed": len(tables or []),
                "total_rows": 0,
                "workers": 0,
                "parallel": bool(parallel),
            }

    def count_rows_multi(self, name: str, tables: list[str]) -> dict:
        """Row-count report for many tables. Mirrors the UI's
        "Show row counts" button. Reuses :meth:`CoreDBService.count_table`.
        """
        if not hasattr(self._core, "count_table"):
            return {"error": "count_table not supported by core service.",
                    "tables": []}
        out: list[dict] = []
        total = 0
        first_err: str | None = None
        for tbl in tables or []:
            r = self._core.count_table(name, tbl)
            err = r.get("error")
            if err and first_err is None:
                first_err = err
            count = int(r.get("count") or 0) if not err else 0
            total += count
            out.append({"table": tbl, "count": count, "error": err})
        return {"error": first_err, "tables": out, "total": total}

    def sample_rows_multi(
        self,
        name: str,
        tables: list[str],
        limit: int = 1,
    ) -> dict:
        """Sample rows for many tables in one call (UI's "Show sample data")."""
        if not hasattr(self._core, "sample_table"):
            return {"error": "sample_table not supported by core service.",
                    "tables": []}
        out: list[dict] = []
        first_err: str | None = None
        for tbl in tables or []:
            r = self._core.sample_table(name, tbl, limit)
            err = r.get("error")
            if err and first_err is None:
                first_err = err
            out.append({
                "table": tbl,
                "columns": r.get("columns") or [],
                "rows": r.get("rows") or [],
                "rowcount": int(r.get("rowcount") or 0),
                "error": err,
            })
        return {"error": first_err, "tables": out}
