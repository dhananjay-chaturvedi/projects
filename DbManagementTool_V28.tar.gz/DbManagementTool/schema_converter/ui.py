"""Schema module UI — embeddable Tk panel + canonical desktop launcher."""

from .schema_converter_ui import SchemaConverterUI, launch_ui
from .standalone import build_tab
from common.core.standalone_runner import launch_lite_ui, launch_shell_ui

__all__ = [
    "SchemaConverterUI",
    "build_tab",
    "launch_ui",
    "launch_lite_ui",
    "launch_shell_ui",
]
