"""Shared target-table naming helpers for data migration.

Used by the UI form, the CLI ``migrator`` command, and the REST migrator API so
all three qualify target table names identically (``source_schema.table`` ->
``target_db.table``) instead of each surface re-implementing the rule.
"""

from __future__ import annotations


def base_table_name(source_table: str) -> str:
    """Return the bare table identifier without a schema/database prefix.

    Handles ``public.t``, ``"public"."t"``, ```db`.`t``` and ``[dbo].[t]``.
    """
    if not source_table:
        return source_table
    table = str(source_table).strip()
    if "." in table:
        table = table.split(".")[-1].strip()
    for left, right in (('"', '"'), ("`", "`"), ("[", "]")):
        if table.startswith(left) and table.endswith(right):
            table = table[1:-1]
    return table


def qualify_target_table(
    source_table: str,
    target_db: str = "",
    prefix: str = "",
    suffix: str = "",
) -> str:
    """Build the target table name from a (possibly qualified) *source_table*.

    Strips the source schema/db, applies *prefix*/*suffix*, and prepends
    *target_db* when supplied so the target SQL is qualified independently of the
    source (``source_schema.orders`` -> ``target_db.mig_orders_copy``).
    """
    base = base_table_name(source_table)
    name = f"{(prefix or '').strip()}{base}{(suffix or '').strip()}"
    target_db = (target_db or "").strip()
    return f"{target_db}.{name}" if target_db else name
